# DATA Compass - Consultant Runbook

This runbook is the operational field guide for consultants deploying DATA Compass at customer sites. It covers pre-engagement planning, Day-1 deployment, configuration tuning, health verification, ongoing operations, troubleshooting, customer handoff, and security hardening. Use it as a sequential checklist for new deployments and a quick-reference for support visits.

**Target audience:** Technical consultants performing on-site or remote deployments for pharmaceutical, biotech, and CRO customers.

**Platform version:** Sprint 13 (Feb 2026)

---

## Table of Contents

1. [Pre-Engagement Checklist](#1-pre-engagement-checklist)
2. [Day-1 Deployment Playbook](#2-day-1-deployment-playbook)
3. [Configuration Cookbook](#3-configuration-cookbook)
4. [Health Verification](#4-health-verification)
5. [Operational Procedures](#5-operational-procedures)
6. [Troubleshooting Quick Reference](#6-troubleshooting-quick-reference)
7. [Customer Handoff](#7-customer-handoff)
8. [Security Checklist](#8-security-checklist)

---

## 1. Pre-Engagement Checklist

Complete every item below **before arriving at the customer site** (or before scheduling the remote deployment session). Share the network requirements document (deploy/NETWORK_REQUIREMENTS.md) with the customer IT team at least one week in advance.

### 1.1 Information to Gather from Customer IT

| Category | Questions to Ask | Notes |
|----------|------------------|-------|
| **Server** | OS, CPU count, RAM, disk space? | Minimum: 2 CPU / 4 GB RAM / 20 GB disk. Recommended: 4 CPU / 8 GB / 50 GB. |
| **Docker** | Docker Engine version? Compose v2 available? | Requires Docker 24+ and Compose v2. |
| **Network** | HTTP proxy required for outbound traffic? | Collect proxy URL, port, auth credentials if any. |
| **DNS** | Can server resolve api.anthropic.com, eutils.ncbi.nlm.nih.gov, data.bioontology.org? | Provide these to the firewall team. |
| **TLS** | Will a reverse proxy handle TLS, or does the app terminate TLS directly? | Reverse proxy is recommended. |
| **Certificates** | PEM certificate and key available? Internal CA or public CA? | If direct TLS: need .crt (full chain) and .key files. |
| **Secrets vault** | Azure Key Vault available? HashiCorp Vault? Or environment variables? | Determines secrets.provider setting. |
| **License** | Has a license key been issued? Edition (Professional/Enterprise)? Expiration date? | Required for production. Contact account manager if not available. |
| **Integrations** | Which platforms? (Stardog, Databricks, Collibra, Veeva, Snowflake) | Determines feature flags and outbound firewall rules. |
| **User directory** | How many initial users? Roles needed (admin, analyst, viewer)? | Collect names, emails, and roles for Day-1 setup. |
| **Branding** | Preferred product name? Customer name for white-label? | Defaults to "Data Compass" if not specified. |
| **AI budget** | Acceptable daily AI API spend? Rate limits? | Default: $10/day, 50 requests/hour. |
| **Backup policy** | Retention period? Backup schedule? Off-site copy required? | Default: 7-day retention, daily at 2:00 AM. |
| **Air-gapped?** | Is the environment fully disconnected from the internet? | If yes, use the offline deployment package. |

### 1.2 Network Requirements Summary

Provide this table to the customer firewall team (full details in deploy/NETWORK_REQUIREMENTS.md):

**Required outbound rules:**

| Destination | Port | Purpose |
|-------------|------|---------|
| api.anthropic.com | 443/HTTPS | AI-powered analysis (Bridge Intelligence, semantic analysis) |
| eutils.ncbi.nlm.nih.gov | 443/HTTPS | Literature-backed AI citations |
| data.bioontology.org | 443/HTTPS | Ontology validation lookups |

**Optional outbound rules (per integration):**

| Destination | Port | Purpose |
|-------------|------|---------|
| Customer Databricks workspace | 443/HTTPS | Unity Catalog integration |
| Customer Collibra instance | 443/HTTPS | Data governance sync |
| Customer Veeva Vault | 443/HTTPS | QMS/CDMS/RIM integration |
| Customer Snowflake account | 443/HTTPS | Data platform integration |
| Customer Stardog instance | 5820/HTTPS | Knowledge graph integration |

**Required inbound rules:**

| Port | Purpose |
|------|---------|
| 443/HTTPS | Web application access for end users |
| 22/SSH | Server administration (restrict to admin IPs) |

> **Data flow guarantee:** Only schema metadata (column names, data types, statistical summaries) is sent to external AI APIs. Raw data values, PII, and file contents never leave the server. No telemetry is collected.

### 1.3 Hardware and Software Prerequisites

| Requirement | Minimum | Recommended |
|-------------|---------|-------------|
| CPU cores | 2 | 4+ |
| RAM | 4 GB | 8 GB+ |
| Disk space | 20 GB | 50 GB+ |
| Docker Engine | 24.x | Latest stable |
| Docker Compose | v2.x | Latest stable |
| OS | Any Linux with Docker support | Ubuntu 22.04 LTS, RHEL 8+, Amazon Linux 2023 |

### 1.4 Pre-Deployment Decision Matrix

Confirm these decisions with the customer before deployment:

- [ ] **License file:** Obtained from account manager? Verify edition, modules, and expiration date.
- [ ] **Deployment mode:** Online or offline (air-gapped)?
- [ ] **Secrets provider:** Environment variables, Azure Key Vault, or encrypted file?
- [ ] **TLS termination:** Reverse proxy or direct?
- [ ] **Branding:** Custom product name and customer name
- [ ] **Feature set:** Which modules to enable (see Section 3.2)
- [ ] **Integrations:** Which external platforms to connect
- [ ] **AI budget:** Daily spend limit and rate limits
- [ ] **Backup schedule:** Frequency and retention period

---

## 2. Day-1 Deployment Playbook

### 2.1 Deployment Overview

The primary entry point is the **setup wizard** (`setup.sh`) at the root of the deployment bundle. It provides a TUI menu (whiptail/dialog/bash fallback) for installation, configuration, health checks, log viewing, backup/restore, and uninstall. Under the hood, it delegates to `deploy/install.sh`, which runs an 8-step process:

1. Prerequisites check (Docker, memory, CPU, disk)
2. Directory structure creation
3. Configuration generation (secrets, proxy, API keys)
4. Docker image pull or load (online vs. offline)
5. Database initialization (PostgreSQL startup)
6. Admin user creation
7. Service startup
8. Health check verification

### 2.2 Online Deployment (Internet-Connected)

**Step 1: Transfer files to the server.**

```bash
scp -r compass-deployment.tar.gz admin@customer-server:/tmp/
ssh admin@customer-server
cd /tmp && tar xzf compass-deployment.tar.gz
```

**Step 2: Launch the setup wizard.**

```bash
sudo ./setup.sh
```

Select **Install** from the menu. The wizard delegates to `deploy/install.sh` with appropriate flags. For non-interactive use:

```bash
sudo ./setup.sh --install --install-dir /opt/compass
```

Or run the installer directly:

```bash
sudo ./deploy/install.sh --install-dir /opt/compass
```

The installer will prompt for:
- License key file path (required for production; obtain from account manager)
- Anthropic API key (required for AI features)
- HTTP proxy URL (if the network requires one)
- Admin email, full name, organization name, and password

To provide the license non-interactively:

```bash
sudo ./deploy/install.sh --license /path/to/compass-license.key
```

**Step 3: Verify installation.**

```bash
curl -s http://localhost:3001/health | python3 -m json.tool
```

Expected response:

```json
{
  "ok": true,
  "env": "production",
  "version": "1.0.0",
  "services": {
    "database": { "healthy": true },
    "storage": { "healthy": true, "backend": "postgres" },
    "schema": { "healthy": true }
  }
}
```

### 2.3 Offline Deployment (Air-Gapped)

**Step 1: Build the offline bundle (on a connected machine).**

```bash
./deploy/package-offline.sh
```

This produces compass-deployment-v{VERSION}.tar.gz containing:
- Pre-built Docker images (compass-images.tar.gz)
- Docker Compose files (docker-compose.yml, docker-compose.prod.yml)
- Configuration template (compass-config.yaml.template)
- All deploy scripts (install.sh, create-admin.sh, backup.sh)
- Documentation files

**Step 2: Transfer the bundle to the target server** via USB drive, secure file transfer, or other approved method.

**Step 3: Extract and install.**

```bash
tar xzf compass-deployment-v*.tar.gz
cd compass-deployment-v*/
sudo ./setup.sh
```

The setup wizard detects the bundled images and offers offline installation. Alternatively:

```bash
sudo ./deploy/install.sh --install-dir /opt/compass --offline
```

**Self-extracting installer option:** If built with `deploy/build-installer.sh`, a single file can be distributed:

```bash
chmod +x compass-setup-v*.sh
sudo ./compass-setup-v*.sh
```

This verifies SHA-256 integrity, extracts, and launches the setup wizard automatically.

### 2.4 Initial Configuration

> **CRITICAL:** Verify `NODE_ENV=production` is set. Without it, the SPA is not served, security headers are relaxed, and error messages leak stack traces. The Docker Compose files set this by default.

After the installer completes, review and customize /opt/compass/compass-config.yaml:

```bash
sudo nano /opt/compass/compass-config.yaml
```

Key sections to verify:

| Section | What to Check |
|---------|---------------|
| license | Verify compass-license.key is present in install directory |
| server.cors_origins | Set to the actual URL users will access |
| database.password | Auto-generated by installer; do not change unless required |
| ai.api_key | Verify Anthropic API key is set |
| proxy.http_proxy | Set if corporate proxy is required |
| branding.product_name | Customize for customer (e.g., "Amgen Data Compass") |
| branding.customer_name | Set customer name (e.g., "Amgen") |
| features.* | Enable/disable modules per customer needs |
| logging.format | Use json for production (feeds into Splunk/ELK) |

After editing, restart the application:

```bash
cd /opt/compass
docker compose -f docker-compose.yml -f docker-compose.prod.yml restart app
```

### 2.5 Admin User Setup

If the installer did not create the admin user (or you need additional admins), use the admin creation script:

```bash
./deploy/create-admin.sh \n  --org "Amgen" \n  --email "admin@amgen.com" \n  --name "Jane Smith" \n  --password "SecureP@ssw0rd!"
```

> **Important:** The password must be at least 8 characters. The script prompts for confirmation if --password is omitted.

For Docker-based execution:

```bash
docker compose exec app node dist/db/seedPocUsers.js \n  --org "Amgen" \n  --email "admin@amgen.com" \n  --name "Jane Smith" \n  --password "SecureP@ssw0rd!"
```

### 2.6 Smoke Test Procedure

An automated smoke test script is included at `deploy/smoke-test.sh`. Run it first, then verify the manual-only items:

```bash
./deploy/smoke-test.sh                         # Default: http://localhost:3001
./deploy/smoke-test.sh --url https://compass.example.com  # Custom URL
```

The script tests endpoints 1-4 and 6 automatically. The full checklist (including manual items) is below. All items should pass before handing the system to the customer.

| # | Test | Command / Action | Expected Result |
|---|------|-----------------|------------------|
| 1 | Liveness | curl -s http://localhost:3001/health/live | {"ok": true, ...} |
| 2 | Readiness | curl -s http://localhost:3001/health/ready | {"ok": true, ...} with all checks passing |
| 3 | Migrations | curl -s http://localhost:3001/health/migrations | {"ok": true, "pending": 0} |
| 4 | Login | Open browser, log in with admin credentials | Dashboard loads successfully |
| 5 | File upload | Upload a sample CSV file | File processes without errors |
| 6 | FAIR assessment | Run a FAIR assessment on uploaded data | Scores are generated |
| 7 | AI synthesis | Trigger Bridge Intelligence on an assessment | AI response is returned (requires API key) |
| 8 | Export | Export an assessment report as PDF | PDF downloads successfully |

---

## 3. Configuration Cookbook

All configuration is managed through compass-config.yaml. The YAML config loader (server/config/compassConfig.ts) reads this file at startup and maps values to environment variables. Environment variables always take precedence over YAML values.

### 3.1 Common Customer Profiles

#### Large Pharma (e.g., Amgen, GSK)

```yaml
branding:
  product_name: "Amgen Data Compass"
  customer_name: "Amgen"

features:
  fair_scoring: true
  ontology_analysis: true
  data_quality: true
  contextual_validity: true
  ml_readiness: true
  privacy_detection: true
  test_agent: true
  literature_ai: true
  governance_lens: true
  stardog_integration: true
  databricks_integration: true
  collibra_integration: false
  veeva_integration: true
  snowflake_integration: true

ai:
  daily_budget_usd: 50.0
  rate_limit_per_hour: 200

database:
  max_connections: 100
```

#### Mid-Size Biotech

```yaml
branding:
  product_name: "Data Compass"
  customer_name: "BioGenesis"

features:
  fair_scoring: true
  ontology_analysis: true
  data_quality: true
  contextual_validity: true
  ml_readiness: true
  privacy_detection: true
  test_agent: false
  literature_ai: true
  governance_lens: true
  stardog_integration: false
  databricks_integration: false
  collibra_integration: false
  veeva_integration: false
  snowflake_integration: false

ai:
  daily_budget_usd: 10.0
  rate_limit_per_hour: 50
```

#### CRO / Consulting Engagement

```yaml
branding:
  product_name: "Data Compass"
  customer_name: ""

features:
  fair_scoring: true
  ontology_analysis: true
  data_quality: true
  contextual_validity: true
  ml_readiness: false
  privacy_detection: false
  test_agent: false
  literature_ai: false
  governance_lens: false
  stardog_integration: false
  databricks_integration: false
  collibra_integration: false
  veeva_integration: false
  snowflake_integration: false

ai:
  daily_budget_usd: 5.0
  rate_limit_per_hour: 30
```

### 3.2 Feature Flag Reference

Each flag maps to an environment variable (ENABLE_<FLAG_NAME>) and controls visibility of the corresponding module in both the server API and client UI.

| Flag (YAML) | Environment Variable | Default | Description |
|-------------|---------------------|---------|-------------|
| fair_scoring | ENABLE_FAIR_SCORING | true | FAIR principle scoring engine |
| ontology_analysis | ENABLE_ONTOLOGY_ANALYSIS | true | Ontology parsing, structural and semantic analysis |
| data_quality | ENABLE_DATA_QUALITY | true | Data quality profiling and DQ score |
| contextual_validity | ENABLE_CONTEXTUAL_VALIDITY | true | Contextual validity probes (R&D, Quality, Commercial) |
| ml_readiness | ENABLE_ML_READINESS | true | ML readiness assessment (Tier 1/2/3) |
| privacy_detection | ENABLE_PRIVACY_DETECTION | true | PII detection and k-anonymity checks |
| test_agent | ENABLE_TEST_AGENT | true | AI test agent for data consumability |
| literature_ai | ENABLE_LITERATURE_AI | true | Literature-backed AI citations (PubMed) |
| governance_lens | ENABLE_GOVERNANCE_LENS | true | Governance document lens (SR 11-7, GDPR, FDA, EU AI Act) |
| stardog_integration | ENABLE_STARDOG_INTEGRATION | false | Stardog knowledge graph integration |
| databricks_integration | ENABLE_DATABRICKS_INTEGRATION | false | Databricks Unity Catalog integration |
| collibra_integration | ENABLE_COLLIBRA_INTEGRATION | false | Collibra data governance integration |
| veeva_integration | ENABLE_VEEVA_INTEGRATION | false | Veeva Vault QMS/CDMS/RIM integration |
| snowflake_integration | ENABLE_SNOWFLAKE_INTEGRATION | false | Snowflake data platform integration |

**Feature flag recipes:**

- **Minimal** (FAIR assessment only): Enable fair_scoring, ontology_analysis, data_quality. Disable everything else.
- **Standard** (most customers): Enable all core modules. Disable integrations.
- **Full** (enterprise pharma): Enable everything including relevant integrations.

### 3.3 Integration Enablement

To enable an integration, set the feature flag to true in the YAML config AND ensure the corresponding outbound firewall rule is in place.

**Stardog Knowledge Graph:**

```yaml
features:
  stardog_integration: true
```

Users configure their Stardog connection through Settings > Integrations in the UI. The connection requires: Stardog server URL (typically port 5820), database name, username and password.

**Databricks:**

```yaml
features:
  databricks_integration: true
```

Connection requires: Workspace URL, personal access token (PAT) or OAuth2 credentials, catalog/schema selection.

**Collibra, Veeva, Snowflake:** Same pattern -- enable the flag, ensure firewall rules, configure via Settings > Integrations UI.

### 3.4 Branding Customization

Branding is configured in compass-config.yaml:

```yaml
branding:
  product_name: "Amgen Data Compass"
  customer_name: "Amgen"
```

The server injects these values into window.__COMPASS_CONFIG__ on the HTML page. The client reads them via client/config/branding.ts.

**What gets branded:**
- Page titles and headings
- Login page tagline (default: "Data Quality & FAIR Assessment Platform")
- Navigation bar product name
- PDF report headers

### 3.5 Secrets Provider Configuration

| Provider | YAML Value | Use Case |
|----------|-----------|----------|
| Environment | environment | Simple deployments |
| Azure Key Vault | azure | Azure deployments |
| Encrypted File | file | Air-gapped environments |

```yaml
secrets:
  provider: azure
  azure_keyvault_url: "https://compass-kv.vault.azure.net/"
```

### 3.6 Proxy Configuration

```yaml
proxy:
  http_proxy: "http://proxy.corp:8080"
  https_proxy: "http://proxy.corp:8080"
  no_proxy: "localhost,127.0.0.1,postgres"
```

### 3.7 License Management

Every production deployment requires a signed license file. The license is a tamper-resistant Ed25519-signed JWT that specifies:
- **Customer** name and ID
- **Edition** (Professional or Enterprise)
- **Activated modules** (e.g., fair_scoring, data_quality, ml_readiness)
- **Activated integrations** (e.g., databricks, stardog)
- **Max users** and **expiration date**

**Verify license status:**

```bash
curl -s http://localhost:3001/api/config/license | python3 -m json.tool
```

**License renewal:** Drop a new `.key` file into the install directory (`/opt/compass/compass-license.key`). The server re-validates hourly — no restart required.

**Grace period:** When a license expires, the system enters a 14-day read-only grace period. Users can still view data but cannot create or modify assessments. After the grace period, the system locks out entirely. Contact the account manager for renewal well before expiration.

**Customer-facing behavior:**
- **Warning banner** appears in the UI when <30 days remain
- **Read-only banner** appears during the grace period
- **Lockout page** appears after grace period expires

### 3.8 Logging

Use json format for production. Rotation configured in docker-compose.prod.yml.

---

## 4. Health Verification

### 4.1 Health Endpoint Reference

| Endpoint | Method | Auth | Purpose |
|----------|--------|------|--------|
| /health | GET | No | Main health check (DB, storage, schema) |
| /health/live | GET | No | Liveness probe (process alive) |
| /health/ready | GET | No | Readiness probe (DB, migrations, AI) |
| /health/migrations | GET | No | Migration status |
| /health/diagnostics | GET | Admin JWT | Full system diagnostics |

### 4.2 Expected Responses

```json
// /health (200 OK)
{
  "ok": true,
  "env": "production",
  "version": "1.0.0",
  "services": {
    "database": { "healthy": true },
    "storage": { "healthy": true, "backend": "postgres" },
    "schema": { "healthy": true }
  }
}
```

```json
// /health/ready (200 OK)
{
  "ok": true,
  "version": "1.0.0",
  "checks": {
    "database": { "ok": true },
    "migrations": { "ok": true, "applied": 93, "pending": 0 },
    "schema": { "ok": true },
    "ai_api": { "ok": true, "status": "healthy" }
  }
}
```

### 4.3 Diagnostics Endpoint

Requires admin JWT. Returns memory, DB pool, AI API status, feature flags, secrets status.

| Field | What to Check |
|-------|---------------|
| uptime_seconds | Should be stable |
| memory.rss_mb | Below 1.5 GB |
| database.status | Must be connected |
| database.active_connections | Below 80% of pool_size |
| ai_api.status | healthy, unconfigured, or unhealthy |
| secrets.loaded_count | At least 3 in production |

### 4.4 Interpreting Failures

| Check | Meaning | Fix |
|-------|---------|-----|
| database.healthy=false | PostgreSQL unreachable | docker compose logs postgres |
| schema.healthy=false | Missing tables | Restart app (auto migrations) |
| ai.status=unhealthy | Cannot reach Anthropic | Check key, proxy, firewall |
| ai.status=unconfigured | No API key | Set ai.api_key in config |

---

## 5. Operational Procedures

### 5.1 Daily Operations Checklist

| # | Task | Command | Expected |
|---|------|---------|----------|
| 1 | Verify services | docker compose ps | Both app and postgres show Up (healthy) |
| 2 | Check health | curl -sf http://localhost:3001/health | {"ok": true} |
| 3 | Review errors | docker compose logs --since 24h app | No unexpected errors |
| 4 | Check disk | df -h /opt/compass | More than 20% free |
| 5 | Verify backup | ./deploy/backup.sh --list | Latest backup within 24 hours |

### 5.2 Backup Operations

```bash
# Manual backup
./deploy/backup.sh

# Automated (cron) - daily at 2AM, 30-day retention
0 2 * * * /opt/compass/deploy/backup.sh --retain 30 >> /opt/compass/logs/backup.log 2>&1

# List backups
./deploy/backup.sh --list

# Restore
./deploy/backup.sh --restore /opt/compass/data/backups/compass_20260208_020000.dump
```

Restore replaces the entire database. Script verifies SHA-256 checksum and prompts for confirmation.

| Variable | Default | Description |
|----------|---------|-------------|
| BACKUP_DIR | /opt/compass/data/backups | Storage directory |
| RETAIN_DAYS | 7 | Retention period |
| POSTGRES_CONTAINER | faircompass-postgres | Container name |
| PGUSER | compassadmin | PostgreSQL user |
| PGDATABASE | compass_dev | Database name |

### 5.3 Log Review

```bash
# Live logs
docker compose logs -f app

# Last hour
docker compose logs --since 1h app

# Errors only (JSON format)
docker compose logs app 2>&1 | grep '"level":"error"'

# PostgreSQL slow queries (over 1 second)
docker compose logs postgres 2>&1 | grep "duration:"
```

### 5.4 User Management

Users are managed through Settings > User Management or via the API.

| Role | Capabilities |
|------|-------------|
| admin | Full access: user management, settings, all modules |
| analyst | Run assessments, view results, export reports |
| viewer | Read-only access to assessments and reports |

### 5.5 Application Updates

```bash
cd /opt/compass
docker compose pull                    # Online
docker load < compass-images.tar.gz    # Offline
docker compose -f docker-compose.yml -f docker-compose.prod.yml up -d
curl -s http://localhost:3001/health/ready
```

Migrations run automatically on startup (RUN_MIGRATIONS=true).

---

## 6. Troubleshooting Quick Reference

### 6.1 Symptom-Cause-Fix Table

| # | Symptom | Likely Cause | Fix |
|---|---------|-------------|-----|
| 1 | App container exits immediately | Config error or missing config | Check logs: docker compose logs app |
| 2 | /health returns 503 | Database unreachable | docker compose ps postgres; docker compose logs postgres |
| 3 | /health/ready 503 with pending migrations | Migrations not applied | docker compose restart app |
| 4 | Login fails | Missing tables or JWT secret | Check /health/migrations; verify JWT_SECRET |
| 5 | CORS error in browser | cors_origins misconfigured | Set server.cors_origins to actual URL |
| 6 | AI features return errors | API key invalid or missing | Check ai.api_key in config |
| 7 | AI features timeout | Proxy blocking Anthropic | Verify proxy settings and firewall |
| 8 | Connection refused on 3001 | App not started | docker compose ps; check port mapping |
| 9 | Blank page after login | Corrupted image or failed load | Re-load images: docker load < compass-images.tar.gz && docker compose up -d app |
| 10 | File upload 413 error | Request body too large | Check reverse proxy max body size |
| 11 | PDF export fails | Puppeteer not available | Check Docker image Chrome deps |
| 12 | DB pool exhaustion | Too many concurrent requests | Check diagnostics; increase max_connections |
| 13 | High memory (over 2 GB) | Large file or memory leak | docker stats; restart app container |
| 14 | TLS certificate errors | Expired or missing chain | Check expiration with openssl |
| 15 | SSL_ERROR_RX_RECORD_TOO_LONG | HTTP/HTTPS port mismatch | Verify TLS config matches URL |
| 16 | Backup script fails | Container not running | Verify POSTGRES_CONTAINER name |
| 17 | Integration connection fails | Firewall blocking outbound | Test from container: docker compose exec app curl <endpoint> |
| 18 | Slow page loads | DB or AI API latency | Check diagnostics duration_ms |
| 19 | Feature not visible in UI | Feature flag disabled | Check features config; restart app |
| 20 | MFA setup fails | Encryption key not set | Set auth.mfa_encryption_key |
| 21 | Ontology parsing error | Invalid OWL/TTL syntax | Validate with Protege or rapper |
| 22 | Rate limit exceeded | Too many API requests | Increase rate_limit_per_hour |
| 23 | Container restart loop | OOM kill | Increase memory in docker-compose.prod.yml |
| 24 | Secrets not loading | Azure credentials wrong | Verify AZURE_KEYVAULT_URL |
| 25 | App crashes on startup with "FATAL: No license file" | License .key file missing | Provide via --license flag or place compass-license.key in install dir |
| 26 | API returns 403 LICENSE_READ_ONLY | License expired (grace period) | Renew license; drop new .key file into install dir |
| 27 | API returns 403 LICENSE_EXPIRED | License expired past grace | Contact account manager urgently; deploy new .key file |
| 28 | API returns 403 MODULE_NOT_LICENSED | Module not in license | Verify license includes the required module; upgrade license if needed |

### 6.2 Diagnostic Commands

```bash
docker compose ps
docker stats --no-stream
du -sh /opt/compass/data/*
docker compose exec postgres psql -U compassadmin -d compass_dev -c "SELECT count(*) FROM pg_stat_activity;"
```

---

## 7. Customer Handoff

### 7.1 Handoff Documentation

Before leaving the customer site, deliver:

| Document | Contents |
|----------|----------|
| Deployment Summary | Date, version, server hostname, install directory |
| Configuration Snapshot | compass-config.yaml with secrets redacted |
| User Accounts | List of users with roles (not passwords) |
| License Details | Edition, expiration date, activated modules, renewal contact |
| Feature Configuration | Which modules are enabled and why |
| Integration Details | Connected systems, endpoints, credentials location |
| Network Topology | Server, proxy, firewall rules, reverse proxy |
| Backup Schedule | Cron expression, retention, location |
| Escalation Contacts | Support email, customer IT admin contacts |

### 7.2 Training Topics

Conduct a 60-90 minute training session covering:

1. Logging in and navigating the dashboard
2. Uploading data and running FAIR assessments
3. Interpreting FAIR scores
4. Ontology analysis (OWL/TTL files)
5. Data quality profiles (genomics, clinical, sensor, financial, commercial)
6. Bridge Intelligence (AI synthesis, data flow guarantees)
7. Exporting reports (PDF and HTML)
8. User management (admin only)
9. Backup and restore (admin only)
10. Health monitoring (admin only)

### 7.3 Support Escalation Path

| Level | Contact | Response Time | Scope |
|-------|---------|---------------|-------|
| L1 | Customer IT admin | Immediate | Restart, health check, logs |
| L2 | Deployment consultant | 4 business hours | Config, troubleshooting, updates |
| L3 | Engineering team | 1 business day | Bug fixes, features, architecture |

### 7.4 Scheduled Maintenance

| Task | Frequency | Downtime |
|------|-----------|----------|
| Application updates | Monthly | 5-10 minutes |
| Backup verification | Weekly | None |
| License renewal check | Monthly | None (curl /api/config/license) |
| TLS certificate renewal | Quarterly check | 1-2 minutes |
| Log review | Daily | None |
| Secrets rotation | Quarterly | 2-5 minutes |
| Disk space audit | Monthly | None |

---

## 8. Security Checklist

### 8.1 Post-Deployment Security Verification

**Configuration Security:**

- [ ] compass-license.key has file permissions 600 (owner read only)
- [ ] compass-config.yaml has file permissions 600 (owner read/write only)
- [ ] No secrets in plain text in Docker Compose files
- [ ] secrets.provider is azure or file in production
- [ ] JWT_SECRET is at least 48 characters of random entropy
- [ ] MFA_ENCRYPTION_KEY is set
- [ ] Database password is at least 32 characters

**Network Security:**

- [ ] HTTPS enforced (TLS via reverse proxy or direct)
- [ ] security.trust_proxy is true if behind reverse proxy
- [ ] security.security_headers is true
- [ ] security.rate_limiting is true
- [ ] security.input_validation is true
- [ ] SSH restricted to admin IPs only
- [ ] PostgreSQL port (5432) NOT exposed to host network

**Access Control:**

- [ ] Default admin password changed
- [ ] No shared accounts
- [ ] Admin role assigned only to required personnel
- [ ] MFA enabled for admin accounts

**Audit:**

- [ ] Audit logging enabled
- [ ] Log format is json
- [ ] Logs collected by customer SIEM

### 8.2 Secrets Rotation Schedule

| Secret | Frequency | Notes |
|--------|-----------|-------|
| Database password | Quarterly | Restart app and postgres |
| JWT secret | Quarterly | Invalidates active sessions |
| MFA encryption key | Annually | Users must re-enroll MFA |
| Anthropic API key | As needed | Restart app |
| TLS certificate | Before expiration | Reload reverse proxy |

### 8.3 Audit Log Review

```bash
# Failed login attempts
docker compose logs app 2>&1 | grep -i "auth.*fail"

# Administrative actions
docker compose logs app 2>&1 | grep -i "admin"
```

### 8.4 Network Security Verification

```bash
# Verify outbound connectivity
curl -sf https://api.anthropic.com -o /dev/null && echo "OK" || echo "BLOCKED"

# Verify PostgreSQL not exposed
ss -tlnp | grep 5432

# Verify security headers
curl -sI https://compass.customer.com | grep -iE "strict-transport|x-content-type|x-frame"
```

Expected headers: Strict-Transport-Security, X-Content-Type-Options: nosniff, X-Frame-Options, Content-Security-Policy.

---

## Appendix A: Quick Command Reference

| Task | Command |
|------|--------|
| Launch setup wizard | sudo ./setup.sh |
| Install (non-interactive) | sudo ./setup.sh --install |
| Health check (non-interactive) | ./setup.sh --health |
| Print version | ./setup.sh --version |
| Start all services | docker compose -f docker-compose.yml -f docker-compose.prod.yml up -d |
| Stop all services | docker compose down |
| Restart application | docker compose restart app |
| View app logs | docker compose logs -f app |
| Check health | curl -s http://localhost:3001/health |
| Check readiness | curl -s http://localhost:3001/health/ready |
| Run backup | ./deploy/backup.sh |
| List backups | ./deploy/backup.sh --list |
| Restore backup | ./deploy/backup.sh --restore <file> |
| Create admin | ./deploy/create-admin.sh --org "Org" --email "a@b.com" --name "Name" |
| Build offline bundle | ./deploy/package-offline.sh |
| Build self-extracting installer | ./deploy/build-installer.sh |
| Container resources | docker stats --no-stream |
| PostgreSQL shell | docker compose exec postgres psql -U compassadmin -d compass_dev |

## Appendix B: Configuration File Locations

| File | Path | Purpose |
|------|------|--------|
| Setup wizard | /opt/compass/setup.sh | TUI entry point |
| License file | /opt/compass/compass-license.key | Signed license (Ed25519 JWT) |
| Main configuration | /opt/compass/compass-config.yaml | All settings |
| Config template | /opt/compass/compass-config.yaml.template | Reference |
| Docker Compose (base) | /opt/compass/docker-compose.yml | Services |
| Docker Compose (prod) | /opt/compass/docker-compose.prod.yml | Production overlay |
| Installer | /opt/compass/deploy/install.sh | 8-step installer |
| Self-extracting builder | /opt/compass/deploy/build-installer.sh | Builds single-file installer |
| Backups | /opt/compass/data/backups/ | PostgreSQL dumps |
| Uploads | /opt/compass/data/uploads/ | User files |
| Exports | /opt/compass/data/exports/ | Generated reports |
| Backup logs | /opt/compass/logs/backup.log | Backup log |

## Appendix C: Environment Variable Override Reference

| YAML Path | Environment Variable |
|-----------|---------------------|
| license.path | COMPASS_LICENSE_PATH |
| server.port | PORT |
| database.host | PGHOST |
| database.port | PGPORT |
| database.name | PGDATABASE |
| database.user | PGUSER |
| database.password | PGPASSWORD |
| auth.jwt_secret | JWT_SECRET |
| auth.mfa_encryption_key | MFA_ENCRYPTION_KEY |
| ai.api_key | ANTHROPIC_API_KEY |
| ai.model | ANTHROPIC_MODEL |
| ai.daily_budget_usd | LLM_DAILY_BUDGET_USD |
| ai.rate_limit_per_hour | LLM_RATE_LIMIT_PER_HOUR |
| logging.format | LOG_FORMAT |
| logging.level | LOG_LEVEL |
| branding.product_name | PRODUCT_NAME |
| branding.customer_name | CUSTOMER_NAME |
| proxy.http_proxy | HTTP_PROXY |
| proxy.https_proxy | HTTPS_PROXY |
| proxy.no_proxy | NO_PROXY |
| security.trust_proxy | TRUST_PROXY |
| secrets.provider | SECRETS_PROVIDER |
