# DATA Compass Installation Guide

Get DATA Compass running in your environment and keep it healthy. This guide covers every deployment path, from one-click cloud setup to air-gapped servers behind corporate firewalls. Follow the section that matches your infrastructure, then use the post-install chapters for TLS, backups, upgrades, and troubleshooting.

DATA Compass is an enterprise data quality and FAIR assessment platform for pharmaceutical and life sciences organizations. Depending on your deployment path, it runs as a managed cloud service (Azure App Service or AWS App Runner) or as two Docker containers (the application and a PostgreSQL database) managed by Docker Compose on your own server.

**Who this guide is for:** IT administrators, infrastructure engineers, and DevOps teams deploying DATA Compass at customer sites. Basic familiarity with Linux terminals, cloud CLIs, or Docker is assumed.

**Version:** 1.0.0 | **Last updated:** March 2026

---

## Table of Contents

0. [Step 0: Choose Your Deployment Path](#0-step-0-choose-your-deployment-path)
1. [Before You Start: Prerequisites](#1-before-you-start-prerequisites)
2. [Installation -- Azure Cloud](#2-installation----azure-cloud)
3. [Installation -- AWS Cloud](#3-installation----aws-cloud)
4. [Installation -- Docker Compose Online](#4-installation----docker-compose-online)
5. [Installation -- Docker Compose Offline / Air-Gapped](#5-installation----docker-compose-offline--air-gapped)
6. [Verify Your Installation](#6-verify-your-installation)
7. [Silent / Unattended Installation](#7-silent--unattended-installation)
8. [Post-Install Configuration](#8-post-install-configuration)
9. [TLS / HTTPS Setup](#9-tls--https-setup)
10. [Admin User Management](#10-admin-user-management)
11. [Backup and Recovery](#11-backup-and-recovery)
12. [Upgrades](#12-upgrades)
13. [Uninstalling](#13-uninstalling)
14. [Troubleshooting](#14-troubleshooting)
- [Appendix A: Quick Command Reference](#appendix-a-quick-command-reference)
- [Appendix B: File Locations](#appendix-b-file-locations)
- [Appendix C: Environment Variable Reference](#appendix-c-environment-variable-reference)

---

## 0. Step 0: Choose Your Deployment Path

DATA Compass supports four deployment paths. All four start from the same installer script (`compass-setup.sh`).

| Path | Best for | What gets created | You manage |
|---|---|---|---|
| **Azure Cloud** | Teams already on Azure who want zero server management | Resource group, PostgreSQL Flexible Server (Standard_B1ms), App Service Plan (P1v3 Linux), web app from `ghcr.io/a-uppal/data-compass:1.0.0` | Azure subscription costs |
| **AWS Cloud** | Teams already on AWS who want zero server management | RDS PostgreSQL (db.t4g.micro, v16, gp3, 20 GB), App Runner service (1024 CPU, 2048 MB memory) | AWS account costs |
| **Docker Compose** | On-premises control, custom infrastructure | Two containers on your Linux server | The server, OS updates, TLS |
| **Air-Gapped** | Secure environments with no outbound internet | Same as Docker Compose, from an offline package | Same as Docker Compose |

The Docker image (`ghcr.io/a-uppal/data-compass:1.0.0`) is **public** on GitHub Container Registry. No registry credentials are needed for any path.

> **Quick Start:** If you want the shortest possible instructions, see the [Quick Start Guide](QUICK_START.md).

---

## 1. Before You Start: Prerequisites

### 1.1 Cloud Paths (Azure or AWS)

You need:

- A workstation (laptop, Cloud Shell, or CloudShell) with internet access
- `curl` or `wget` installed
- **Azure:** Azure CLI (`az`) installed and logged in (`az login`), an active subscription
- **AWS:** AWS CLI (`aws`) installed and configured (`aws configure`), IAM permissions to create RDS instances, App Runner services, and security groups

No server or VM is required.

### 1.2 Docker Compose Paths (Online or Air-Gapped)

#### Operating System

DATA Compass runs on any Linux distribution with Docker support:

- Ubuntu 22.04 LTS or 24.04 LTS (recommended)
- RHEL 8+ (Red Hat Enterprise Linux)
- Amazon Linux 2023

Windows and macOS are supported for development only, not production deployment.

#### Hardware Requirements

| Resource | Minimum | Recommended | Why |
|---|---|---|---|
| CPU cores | 2 | 4+ | AI analysis and concurrent users benefit from more cores |
| RAM | 4 GB | 8+ GB | PostgreSQL and the app each need headroom |
| Disk | 20 GB | 50+ GB | Database, Docker images, uploaded datasets, backups |

#### Software Requirements

| Software | Minimum version | Check command |
|---|---|---|
| Docker Engine | 24.0 | `docker --version` |
| Docker Compose | v2.0 | `docker compose version` |
| bash | 4.0 | `bash --version` |
| openssl | 1.1 | `openssl version` |
| curl or wget | Any | `curl --version` or `wget --version` |

If Docker is not installed, the installer will offer to install it automatically (Debian/Ubuntu, RHEL/CentOS, or Fedora).

#### Network Requirements

**Inbound ports:**

| Port | Protocol | Purpose |
|---|---|---|
| 443 | HTTPS | Web application (after TLS is configured) |
| 3001 | HTTP | Web application (default, before TLS) |
| 22 | SSH | Server administration (restrict to admin IPs) |

**Outbound connections (required):**

| Destination | Port | Purpose |
|---|---|---|
| `api.anthropic.com` | 443 | Claude AI API for Bridge Intelligence and semantic analysis |
| `eutils.ncbi.nlm.nih.gov` | 443 | PubMed for literature-backed citations |
| `data.bioontology.org` | 443 | BioPortal ontology lookup and validation |
| `ghcr.io` | 443 | Docker image registry (first install and upgrades) |
| `compassfordata.com` | 443 | Deploy bundle download |

**Outbound connections (optional, by integration):**

| Destination | Port | Purpose |
|---|---|---|
| Customer Databricks workspace | 443 | Databricks Unity Catalog integration |
| Customer Collibra instance | 443 | Collibra data governance integration |
| Customer Veeva Vault | 443 | Veeva QMS/CDMS/RIM integration |
| Customer Snowflake account | 443 | Snowflake data platform integration |
| Customer Stardog instance | 5820 | Stardog knowledge graph integration |

For full network documentation, see [Network Requirements](NETWORK_REQUIREMENTS.md).

---

## 2. Installation -- Azure Cloud

The installer creates all Azure resources in your subscription: a resource group, PostgreSQL Flexible Server, App Service Plan, and a web app running the DATA Compass container image. You do not need a VM or server.

### 2.1 Prerequisites

- Azure CLI installed: `az version`
- Logged in: `az login`
- An active subscription with permissions to create resource groups, PostgreSQL servers, App Service plans, and web apps

> **Tip:** You can run the installer directly from [Azure Cloud Shell](https://shell.azure.com), which has `az` pre-installed.

### 2.2 Run the Installer

```bash
curl -fsSL https://compassfordata.com/download/compass-setup.sh -o compass-setup.sh
chmod +x compass-setup.sh
sudo ./compass-setup.sh
```

### 2.3 License Prompt

The installer shows a banner, then asks for your license file:

```
License file path (Enter for 30-day evaluation):
```

If you have a `compass-license.key` file, enter its full path. The installer validates the JWT, displays the customer name, edition, and expiration date. If you press Enter, DATA Compass starts in 30-day evaluation mode with all modules unlocked.

### 2.4 Deployment Menu

After the license prompt, a deployment menu appears:

```
How would you like to deploy DATA Compass?

  1)  Azure Cloud        Azure App Service + managed PostgreSQL
  2)  AWS Cloud          AWS App Runner + RDS PostgreSQL
  3)  Docker Compose     Install on your own Linux server
  4)  Air-gapped         Offline install (no internet required)
  q)  Quit

Select [1-4/q]:
```

Select **1**.

### 2.5 Configuration (Step 1/5)

The installer generates a random suffix to avoid Azure naming conflicts and prompts for:

| Prompt | Default | Notes |
|---|---|---|
| Resource group name | `compass-rg` | Standard Azure resource group |
| Region | `eastus` | Azure region for all resources |
| Web app name | `compass-<random>` | Becomes `<name>.azurewebsites.net` |
| Database server name | `compass-db-<random>` | Becomes `<name>.postgres.database.azure.com` |
| Database admin username | `compassadmin` | PostgreSQL admin user |
| Database admin password | Auto-generated | Press Enter to auto-generate a strong password |
| Admin email | (required) | Your login email for DATA Compass |
| Admin full name | (required) | Displayed in the application |
| Organization name | (required) | Your company name |
| Admin password | (required) | Min 8 characters |
| Anthropic API key | (optional) | Starts with `sk-ant-`. Powers AI features. |

The installer shows a configuration summary and asks you to confirm before creating any resources.

### 2.6 Resource Creation (Steps 2-3/5)

The installer creates:

1. **Resource group** in your chosen region
2. **PostgreSQL Flexible Server** (Standard_B1ms, Burstable tier, PostgreSQL 16, 32 GB storage). If the chosen region is unavailable, the installer automatically tries `eastus`, `eastus2`, `westus2`, `northeurope`, `westeurope`, and `centralus`.
3. **Firewall rule** allowing Azure services to connect to PostgreSQL
4. **App Service Plan** (P1v3, Linux)
5. **Web app** from the public Docker image `ghcr.io/a-uppal/data-compass:1.0.0` -- no registry credentials are needed
6. **Container logging** enabled to filesystem
7. **Environment variables** for database connection, authentication secrets, storage config, and security settings
8. **Health check path** set to `/health/live`

If you provided a license file, it is base64-encoded and injected as the `COMPASS_LICENSE_B64` environment variable. This takes priority over file-based license detection in the server.

### 2.7 Application Startup (Step 4/5)

The installer restarts the app to apply the configuration, then waits for `https://<app-name>.azurewebsites.net/health` to return HTTP 200. The first start runs 93 database migrations, which typically takes 2-5 minutes.

### 2.8 Admin User Creation (Step 5/5)

The installer registers your admin user via the `/api/auth/register` API endpoint, then connects to the PostgreSQL server using `az postgres flexible-server execute` to verify the email address and set the admin role:

```sql
UPDATE users SET email_verified = true, role = 'admin' WHERE email = '<your-email>';
```

If the SQL step fails (some subscriptions restrict this command), the installer prints instructions for doing it manually via the Azure Portal.

### 2.9 Done

The installer displays your deployment URL:

```
DATA Compass is deployed!

URL:           https://compass-a1b2c3.azurewebsites.net
Admin email:   admin@yourcompany.com
Resource group: compass-rg
```

**Useful management commands:**

```bash
az webapp log tail -g compass-rg -n compass-a1b2c3    # Stream logs
az webapp restart -g compass-rg -n compass-a1b2c3      # Restart app
az group delete -n compass-rg --yes                     # Tear down everything
```

---

## 3. Installation -- AWS Cloud

The installer creates an RDS PostgreSQL instance and an App Runner service in your AWS account. You do not need a VM or server.

### 3.1 Prerequisites

- AWS CLI installed: `aws --version`
- Credentials configured: `aws sts get-caller-identity` should return your account ID
- IAM permissions to create RDS instances, App Runner services, and related resources

> **Tip:** You can run the installer from [AWS CloudShell](https://console.aws.amazon.com/cloudshell), which has `aws` pre-installed.

### 3.2 Run the Installer

```bash
curl -fsSL https://compassfordata.com/download/compass-setup.sh -o compass-setup.sh
chmod +x compass-setup.sh
sudo ./compass-setup.sh
```

### 3.3 License and Deployment Menu

Same as the Azure path: enter your license file path (or press Enter for evaluation), then select **2** from the deployment menu.

### 3.4 Configuration (Step 1/5)

| Prompt | Default | Notes |
|---|---|---|
| AWS region | `us-east-1` | Region for all resources |
| Service name | `compass-<random>` | Used for App Runner and RDS naming |
| Database admin username | `compassadmin` | RDS master user |
| Database admin password | Auto-generated | Press Enter to auto-generate |
| Admin email | (required) | Your DATA Compass login |
| Admin full name | (required) | Displayed in the application |
| Organization name | (required) | Your company name |
| Admin password | (required) | Min 8 characters |
| Anthropic API key | (optional) | Powers AI features |

### 3.5 Resource Creation (Steps 2-3/5)

The installer creates:

1. **RDS PostgreSQL instance** (db.t4g.micro, PostgreSQL 16, gp3 storage, 20 GB, 7-day backup retention, publicly accessible, single-AZ)
2. Waits for the instance to become available (5-10 minutes)
3. **App Runner service** using the public Docker image `ghcr.io/a-uppal/data-compass:1.0.0` with `ECR_PUBLIC` image type (1024 CPU units, 2048 MB memory)
4. **Health check** configured on `/health/live` (interval 10s, timeout 5s)
5. **Environment variables** for database connection, authentication secrets, storage config, and security settings

If you provided a license file, it is base64-encoded and injected as `COMPASS_LICENSE_B64`.

### 3.6 Application Startup (Step 4/5)

The installer polls the App Runner service status, waiting for it to reach `RUNNING`. This takes 3-8 minutes. First start runs 93 database migrations.

### 3.7 Admin User Creation (Step 5/5)

The installer registers your admin user via the API. Because the installer cannot directly execute SQL against RDS from the command line, it prints instructions to verify the email and set the admin role:

```bash
psql "host=<rds-endpoint> user=compassadmin dbname=postgres sslmode=require"
```

```sql
UPDATE users SET email_verified = true, role = 'admin' WHERE email = 'admin@yourcompany.com';
```

### 3.8 Done

```
DATA Compass is deployed!

URL:           https://abc123xyz.us-east-1.awsapprunner.com
Admin email:   admin@yourcompany.com
Region:        us-east-1
```

**Useful management commands:**

```bash
# View logs
# AWS Console > App Runner > compass-<id> > Logs

# Tear down
aws apprunner delete-service --service-arn <arn> --region us-east-1
aws rds delete-db-instance --db-instance-identifier compass-<id>-db --skip-final-snapshot --region us-east-1
```

---

## 4. Installation -- Docker Compose Online

This path installs DATA Compass on your own Linux server using Docker Compose. You have full control over the infrastructure.

### 4.1 Run the Installer

Connect to your server via SSH, then:

```bash
curl -fsSL https://compassfordata.com/download/compass-setup.sh -o compass-setup.sh
chmod +x compass-setup.sh
sudo ./compass-setup.sh
```

### 4.2 License and Deployment Menu

Enter your license file path (or press Enter for evaluation), then select **3** from the deployment menu.

### 4.3 What Happens Next

After you select **3 (Docker Compose)**, `compass-setup.sh`:

1. Checks prerequisites (root, curl/wget, Docker, Compose, system resources)
2. Downloads the deploy bundle (~100 KB) from `https://compassfordata.com/releases/v1.0.0/compass-deploy-v1.0.0.tar.gz`
3. Verifies the SHA-256 checksum
4. Extracts the bundle to a temporary directory
5. Hands off to the 8-step setup wizard (`install.sh`)

### 4.4 The 8-Step Setup Wizard

#### Step 1/8: Prerequisites Check

Verifies Docker Engine, Docker Compose v2, system tools, RAM, disk space, port availability (3001), and SELinux status. If Docker is missing, the wizard offers to install it.

#### Step 2/8: Directory Structure

Creates the installation directory (default `/opt/compass`) with subdirectories:

```
/opt/compass/
  data/uploads/       User-uploaded files (CSV, Excel)
  data/exports/       Generated reports (PDF, Excel)
  data/backups/       Database backup files
  logs/               Installation and application logs
```

Copies Docker Compose files and deploy scripts into the installation directory.

#### Step 3/8: Generate Configuration

The wizard prompts for three values:

| Prompt | Notes |
|---|---|
| License file path | Enter the same path you used earlier, or press Enter to skip. The file is copied into `/opt/compass/compass-license.key`. |
| Anthropic API key | Starts with `sk-ant-`. Enter to skip. AI features will be unavailable without this. |
| HTTP proxy URL | Corporate proxy (e.g., `http://proxy.corp.example.com:8080`). Enter to skip. |

The wizard auto-generates strong secrets for:
- PostgreSQL password (32 characters)
- JWT secret (48 characters)
- MFA encryption key (32 characters)

It creates two files:
- `/opt/compass/compass-config.yaml` -- application configuration
- `/opt/compass/.env` -- Docker Compose environment variables (contains secrets, readable only by root)

If you provided a license file, the wizard sets `COMPASS_LICENSE_REQUIRED=true` in `.env`. If you skipped the license, it sets `COMPASS_LICENSE_REQUIRED=false`.

#### Step 4/8: Pull Docker Images

Pulls images from `ghcr.io` (GitHub Container Registry). The image is **public** -- no authentication or registry credentials are required. This is a one-time ~700 MB download.

For offline installs, this step loads images from the bundled `compass-images.tar.gz` instead.

#### Step 5/8: Initialize Database

Starts the PostgreSQL container and waits for it to be ready (up to 60 seconds). The database itself runs PostgreSQL 16 Alpine. Migrations run automatically on first app startup.

#### Step 6/8: Create Initial Admin User

In interactive mode, the wizard prompts for:

| Prompt | Notes |
|---|---|
| Admin email | Required. Your login email. |
| Admin full name | Required. Displayed in the application. |
| Organization name | Required. Your company name. |
| Admin password | Required. Minimum 8 characters. Input is hidden. |

The wizard starts the application (with both `docker-compose.yml` and `docker-compose.prod.yml`), waits up to 5 minutes for migrations to complete and the app to become healthy, then creates the admin user by running `node dist/db/seedPocUsers.js` inside the container.

> **Note:** First boot runs 93 database migrations. This takes 2-5 minutes on minimum hardware. The wizard shows a spinner during this wait.

#### Step 7/8: Start Services

Starts all services with production settings:

```bash
docker compose -f docker-compose.yml -f docker-compose.prod.yml up -d --no-build
```

#### Step 8/8: Health Check

Polls `http://localhost:3001/health/ready` every 2 seconds for up to 120 seconds. When the application responds, the wizard displays:

```
=====================================
  DATA Compass is ready!
=====================================

  Access URL:     http://your-server:3001
  Admin email:    admin@yourcompany.com
  Config file:    /opt/compass/compass-config.yaml
  Install log:    /opt/compass/logs/install.log
  Logs:           docker compose logs -f app
  Stop:           docker compose down
```

---

## 5. Installation -- Docker Compose Offline / Air-Gapped

For servers with no outbound internet access.

### 5.1 Prepare the Offline Package (on a machine with internet)

Download the offline deployment package (~700 MB) from `https://compassfordata.com/download`, or build it yourself using `deploy/package-offline.sh`. This package includes:

- All Docker images (pre-saved as `compass-images.tar.gz`)
- Deploy scripts, Docker Compose files, and configuration templates
- The installer wizard

### 5.2 Transfer to the Air-Gapped Server

Use a USB drive, secure file transfer, or other approved method to copy the package to the target server.

### 5.3 Install

On the air-gapped server:

```bash
tar xzf compass-deployment-v1.0.0.tar.gz
cd compass-deployment-v1.0.0
sudo ./setup.sh
```

Alternatively, use the deploy bundle directly with `install.sh`:

```bash
sudo ./deploy/install.sh --install-dir /opt/compass --offline
```

The `--offline` flag tells the wizard to load Docker images from the bundled tarball instead of pulling from the internet. All other steps (directory creation, configuration, database init, admin user, health check) are identical to the online path described in [Section 4](#4-installation----docker-compose-online).

---

## 6. Verify Your Installation

After installation completes, verify that everything is working correctly.

### 6.1 Health Endpoints

DATA Compass exposes four health endpoints:

| Endpoint | What it checks | Expected response |
|---|---|---|
| `/health` | Full health (DB, app, migrations) | `{"ok":true, ...}` |
| `/health/live` | Process is running | HTTP 200 |
| `/health/ready` | App is ready to serve requests | HTTP 200 |
| `/health/migrations` | Database migration status | `{"pending":0, ...}` |

**Check from the server (Docker Compose):**

```bash
curl -s http://localhost:3001/health
curl -s http://localhost:3001/health/migrations
```

**Check from outside (cloud or any path):**

```bash
curl -s https://your-deployment-url/health
```

### 6.2 Smoke Tests (Docker Compose only)

Run the automated smoke test suite:

```bash
./deploy/smoke-test.sh
```

Or against a custom URL:

```bash
./deploy/smoke-test.sh --url https://compass.yourcompany.com
```

The smoke test checks 7 endpoints:

1. `GET /health/live` -- HTTP 200
2. `GET /health/ready` -- HTTP 200
3. `GET /health` -- response contains `"ok":true`
4. `GET /health/migrations` -- 0 pending migrations
5. `GET /` -- HTTP 200 (SPA serving)
6. `GET /login` -- HTTP 200 (SPA route)
7. `GET /api/journey` -- HTTP 401 (API responding, requires auth)

### 6.3 Container Status (Docker Compose only)

```bash
cd /opt/compass
docker compose ps
```

Expected output:

```
NAME                  IMAGE                                      STATUS                  PORTS
faircompass-app       ghcr.io/a-uppal/data-compass:1.0.0        Up About a minute (healthy)   0.0.0.0:3001->8080/tcp
faircompass-postgres  postgres:16-alpine                         Up About a minute (healthy)   127.0.0.1:5432->5432/tcp
```

> **Important:** The PostgreSQL port binds to `127.0.0.1` only. It is not accessible from outside the server.

### 6.4 Browser Login

Open your deployment URL in a browser and log in with the admin email and password you created during installation. You should see the DATA Compass dashboard.

---

## 7. Silent / Unattended Installation

For automated deployments, CI/CD pipelines, or scripted provisioning.

### 7.1 Required Flag

Silent mode **requires** the `--deploy-type` flag. Without it, the installer exits with an error:

```
[FAIL] --deploy-type is required in silent mode.
[FAIL] Options: azure, aws, docker, airgap
```

### 7.2 Required Environment Variables

| Variable | Description |
|---|---|
| `COMPASS_ADMIN_EMAIL` | Admin login email address |
| `COMPASS_ADMIN_PASSWORD` | Admin password (min 8 characters) |
| `COMPASS_ADMIN_NAME` | Admin full name |
| `COMPASS_ADMIN_ORG` | Organization name |

### 7.3 Optional Environment Variables

| Variable | Description | Default |
|---|---|---|
| `COMPASS_AI_KEY` | Anthropic API key (`sk-ant-...`) | None (AI features disabled) |
| `COMPASS_PROXY_URL` | HTTP proxy URL | None |
| `COMPASS_LICENSE_FILE` | Path to license `.key` file | None (30-day evaluation) |
| `COMPASS_LICENSE_B64` | Base64-encoded license JWT (for cloud) | None |
| `COMPASS_LICENSE_REQUIRED` | Enforce license validation | `false` |
| `COMPASS_INSTALL_DIR` | Installation directory | `/opt/compass` |
| `COMPASS_PORT` | Application HTTP port | `3001` |
| `COMPASS_DOWNLOAD_URL` | Override deploy bundle URL | `https://compassfordata.com/releases` |
| `COMPASS_IMAGE` | Override Docker image reference | `ghcr.io/a-uppal/data-compass:1.0.0` |
| `COMPASS_INSTALL_DOCKER` | Auto-install Docker if missing | Not set (set to `yes` to enable) |

### 7.4 Online Silent Install (Docker Compose)

```bash
curl -fsSL https://compassfordata.com/download/compass-setup.sh | \
sudo COMPASS_ADMIN_EMAIL=admin@example.com \
COMPASS_ADMIN_PASSWORD='Str0ngP@ss!' \
COMPASS_ADMIN_NAME="Admin User" \
COMPASS_ADMIN_ORG="Acme Corp" \
bash -s -- --deploy-type docker --silent
```

### 7.5 Offline Silent Install

```bash
sudo COMPASS_ADMIN_EMAIL=admin@example.com \
COMPASS_ADMIN_PASSWORD='Str0ngP@ss!' \
COMPASS_ADMIN_NAME="Admin User" \
COMPASS_ADMIN_ORG="Acme Corp" \
./compass-setup.sh --deploy-type docker --silent
```

### 7.6 Silent Install with All Options

```bash
export COMPASS_ADMIN_EMAIL=admin@pharma.com
export COMPASS_ADMIN_PASSWORD='SecureP@ssw0rd'
export COMPASS_ADMIN_NAME="Admin User"
export COMPASS_ADMIN_ORG="Pharma Corp"
export COMPASS_AI_KEY="sk-ant-api03-..."
export COMPASS_PROXY_URL="http://proxy.corp.example.com:8080"
export COMPASS_LICENSE_FILE="/path/to/compass-license.key"
export COMPASS_INSTALL_DOCKER=yes

sudo -E ./compass-setup.sh --deploy-type docker --silent --install-dir /opt/compass
```

### 7.7 Silent Azure Deployment

For Azure cloud deployment in silent mode, the installer currently requires interactive prompts for resource names and credentials. Use the `--deploy-type azure` flag with pre-configured Azure CLI settings.

### 7.8 Verify Silent Install

After a silent install completes, verify with:

```bash
curl -sf http://localhost:3001/health && echo "Healthy" || echo "Not ready"
./deploy/smoke-test.sh
```

---

## 8. Post-Install Configuration

All configuration lives in two files in the installation directory (default `/opt/compass`):

| File | Purpose | Permissions |
|---|---|---|
| `compass-config.yaml` | Application settings (AI, proxy, branding, features, TLS) | `644` |
| `.env` | Docker Compose variable interpolation (secrets, passwords, feature flags) | `600` |

Environment variables override YAML values. The `.env` file is read by Docker Compose and its values are injected into the container.

### 8.1 Feature Flags

Control which modules are available to users:

```yaml
# In compass-config.yaml
features:
  fair_scoring: true
  ontology_analysis: true
  data_quality: true
  contextual_validity: true
  ml_readiness: true
  privacy_detection: true
  test_agent: true
  literature_ai: true
  governance_lens: true
  stardog_integration: false       # Requires Stardog infrastructure
  databricks_integration: false    # Requires Databricks workspace
  collibra_integration: false      # Requires Collibra instance
  veeva_integration: false         # Requires Veeva Vault
  snowflake_integration: false     # Requires Snowflake account
```

Integration features are disabled by default because they require external infrastructure.

### 8.2 AI Configuration

```yaml
# In compass-config.yaml
ai:
  provider: anthropic
  api_key: "sk-ant-..."          # Or set ANTHROPIC_API_KEY in .env
  model: claude-sonnet-4-5-20250929
  max_tokens: 4000
  temperature: 0.7
  daily_budget_usd: 10.0          # Spending cap per 24 hours
  rate_limit_per_hour: 50          # Max API calls per hour
```

> **Important:** Without an Anthropic API key, AI-powered features (Bridge Intelligence, semantic ontology analysis, contextual fit probing, governance lens deep analysis) will be unavailable. All non-AI features work normally.

### 8.3 Branding

Customize the product name and customer name displayed in the application:

```yaml
# In compass-config.yaml
branding:
  product_name: "DATA Compass"
  customer_name: "Amgen"          # Shown in the header
```

Or via environment variables:

```bash
# In .env
PRODUCT_NAME=DATA Compass
CUSTOMER_NAME=Amgen
```

### 8.4 Proxy Configuration

If your server accesses the internet through an HTTP proxy:

```yaml
# In compass-config.yaml
proxy:
  http_proxy: "http://proxy.corp.example.com:8080"
  https_proxy: "http://proxy.corp.example.com:8080"
  no_proxy: "localhost,127.0.0.1,postgres"
```

> **Important:** Always include `localhost,127.0.0.1,postgres` in `no_proxy` to prevent internal traffic from being routed through the proxy.

### 8.5 Secrets Management

By default, secrets (database password, JWT secret, MFA encryption key) are stored in the `.env` file in the installation directory. For enterprise deployments, DATA Compass supports pluggable secrets backends via the `secrets.provider` setting:

| Provider | Value | Description |
|---|---|---|
| Environment variables | `environment` | Default. Reads from `.env` file passed to Docker Compose. |
| Azure Key Vault | `azure` | Reads secrets from Azure Key Vault at runtime. Requires managed identity or service principal. |
| File-based | `file` | Reads secrets from individual files on disk (e.g., Docker secrets or Kubernetes mounted volumes). |
| HashiCorp Vault | `vault` | Reads secrets from HashiCorp Vault via HTTP API. |

To switch to Azure Key Vault, set in `compass-config.yaml`:

```yaml
secrets:
  provider: "azure"
  azure_key_vault_url: "https://your-vault.vault.azure.net"
```

### 8.6 Applying Configuration Changes

After editing `compass-config.yaml` or `.env`:

```bash
cd /opt/compass
docker compose -f docker-compose.yml -f docker-compose.prod.yml restart app
```

The app container re-reads the configuration on startup. No data is lost during a restart.

---

## 9. TLS / HTTPS Setup

DATA Compass serves HTTP on port 3001 by default. For production, you must enable TLS (HTTPS). There are two approaches.

### Option A: Reverse Proxy (Recommended)

Use nginx, Caddy, or your organization's load balancer to terminate TLS and forward traffic to DATA Compass.

**Example nginx configuration:**

```nginx
server {
    listen 443 ssl;
    server_name compass.yourcompany.com;

    ssl_certificate     /etc/ssl/certs/compass.pem;
    ssl_certificate_key /etc/ssl/private/compass.key;

    location / {
        proxy_pass http://127.0.0.1:3001;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

Then update `compass-config.yaml`:

```yaml
security:
  trust_proxy: true

server:
  cors_origins:
    - "https://compass.yourcompany.com"
```

### Option B: Direct TLS

Configure DATA Compass to serve HTTPS directly by adding TLS settings to `compass-config.yaml`:

```yaml
tls:
  cert_path: /etc/ssl/certs/compass.pem
  key_path: /etc/ssl/private/compass.key
```

You also need to mount the certificate files into the container. Add volume mounts to `docker-compose.prod.yml`:

```yaml
services:
  app:
    volumes:
      - /etc/ssl/certs/compass.pem:/etc/ssl/certs/compass.pem:ro
      - /etc/ssl/private/compass.key:/etc/ssl/private/compass.key:ro
```

### Enabling HSTS

After TLS is working correctly, enable HTTP Strict Transport Security:

```bash
# In /opt/compass/.env
ENABLE_HSTS=true
```

Then restart the app:

```bash
cd /opt/compass
docker compose -f docker-compose.yml -f docker-compose.prod.yml restart app
```

> **Warning:** Only enable HSTS **after** TLS is confirmed working. Enabling HSTS over plain HTTP will cause browsers to refuse non-HTTPS connections, which can lock users out.

---

## 10. Admin User Management

### 10.1 Creating Admin Users

Use the `create-admin.sh` script:

```bash
./deploy/create-admin.sh \
  --org "Acme Pharma" \
  --email admin@acme.com \
  --name "Jane Smith"
```

If `--password` is omitted, you will be prompted interactively (with confirmation). The script detects whether it is running in a Docker deployment (exec into the container) or a development environment (local Node.js).

**Flags:**

| Flag | Required | Description |
|---|---|---|
| `--org` | Yes | Organization name |
| `--email` | Yes | Email address (validated for format) |
| `--name` | Yes | Full name |
| `--password` | No | Password (prompted if omitted, min 8 characters) |

### 10.2 User Roles

DATA Compass has three roles:

| Role | Capabilities |
|---|---|
| `admin` | Full access: manage users, configure settings, run assessments |
| `analyst` | Run assessments, upload data, view results. Cannot change system configuration. |
| `viewer` | Read-only access to existing assessments and reports |

### 10.3 Changing User Roles

User roles can be managed through the administration interface in the web application (Settings > User Management) or by direct database update:

```bash
docker compose exec postgres psql -U compassadmin -d compass_dev -c \
  "UPDATE users SET role = 'admin' WHERE email = 'user@example.com';"
```

---

## 11. Backup and Recovery

### 11.1 Manual Backup

```bash
./deploy/backup.sh
```

This creates a compressed PostgreSQL dump in `/opt/compass/data/backups/`:

```
/opt/compass/data/backups/compass_20260316_140000.dump
/opt/compass/data/backups/compass_20260316_140000.dump.sha256
```

**Flags:**

| Flag | Description |
|---|---|
| `--retain N` | Keep backups for N days (default: 7). Older backups are deleted. |
| `--list` | List available backups with file sizes |
| `--restore FILE` | Restore from a backup file |

### 11.2 Automated Backups (Cron)

Schedule daily backups at 2 AM with 30-day retention:

```bash
# Add to root's crontab:
0 2 * * * /opt/compass/deploy/backup.sh --retain 30 >> /opt/compass/logs/backup.log 2>&1
```

### 11.3 List Backups

```bash
./deploy/backup.sh --list
```

### 11.4 Restore from Backup

```bash
./deploy/backup.sh --restore /opt/compass/data/backups/compass_20260316_140000.dump
```

The script verifies the SHA-256 checksum (if available), warns that the restore will replace the current database, and asks for confirmation before proceeding.

> **Warning:** Restoring a backup replaces all current data. Create a fresh backup before restoring if you want to preserve the current state.

### 11.5 Backup Environment Variables

| Variable | Default | Description |
|---|---|---|
| `BACKUP_DIR` | `/opt/compass/data/backups` | Backup output directory |
| `RETAIN_DAYS` | `7` | Retention period in days |
| `POSTGRES_CONTAINER` | `faircompass-postgres` | Docker container name |
| `PGUSER` | `compassadmin` | PostgreSQL user |
| `PGDATABASE` | `compass_dev` | PostgreSQL database name |

---

## 12. Upgrades

### 12.1 Online Upgrade

The `upgrade.sh` script handles the full upgrade process: pre-flight checks, automatic backup, image pull, restart, health check, and smoke tests.

```bash
cd /opt/compass
./deploy/upgrade.sh
```

To pin a specific version:

```bash
./deploy/upgrade.sh --version 1.0.1
```

The `--version` flag writes `COMPASS_VERSION=<version>` to `.env`, which Docker Compose uses to pull the correct image tag.

### 12.2 Offline Upgrade

Transfer the new image tarball to the server, then:

```bash
./deploy/upgrade.sh --bundle compass-images-v1.0.1.tar.gz
```

### 12.3 Upgrade Steps

The upgrade script performs 7 steps:

1. **Pre-flight checks** -- Docker, Compose, running containers
2. **Capture current image** -- saves the current image tag for rollback
3. **Auto-backup database** -- runs `backup.sh` automatically
4. **Load/pull new images** -- from registry or bundle file
5. **Restart services** -- `docker compose up -d`
6. **Health check** -- polls `/health/ready` for up to 120 seconds
7. **Smoke tests** -- runs `smoke-test.sh` if available

### 12.4 Upgrade Flags

| Flag | Description |
|---|---|
| `--bundle FILE` | Offline: load images from tarball |
| `--version VERSION` | Pin a specific version (e.g., `1.0.1`) |
| `--dry-run` | Preview upgrade steps without executing |
| `--install-dir DIR` | Installation directory (default: `/opt/compass`) |

### 12.5 Dry Run

Preview what the upgrade will do without making any changes:

```bash
./deploy/upgrade.sh --dry-run
```

### 12.6 Rollback

If the upgrade fails (health check does not pass within 120 seconds), the script prints rollback instructions:

```bash
# 1. Stop the new version
docker compose -f docker-compose.yml -f docker-compose.prod.yml down

# 2. Restore the pre-upgrade backup
./deploy/backup.sh --restore <pre-upgrade-backup-file>

# 3. Restart with the previous version
docker compose -f docker-compose.yml -f docker-compose.prod.yml up -d
```

### 12.7 Cloud Upgrades

For Azure and AWS cloud deployments, update the container image:

**Azure:**
```bash
az webapp config container set \
  -g compass-rg -n compass-a1b2c3 \
  --container-image-name ghcr.io/a-uppal/data-compass:1.0.1
az webapp restart -g compass-rg -n compass-a1b2c3
```

**AWS:**
Update the App Runner service in the AWS Console or via CLI to use the new image tag, then trigger a new deployment.

---

## 13. Uninstalling

### 13.1 Stop Only (Preserve Data)

Stop containers but keep all data, configuration, and images:

```bash
sudo ./deploy/uninstall.sh
```

You will be asked to confirm. The data directory (`/opt/compass/data/`) is preserved. To restart later:

```bash
cd /opt/compass
docker compose -f docker-compose.yml -f docker-compose.prod.yml up -d
```

### 13.2 Full Purge

Remove containers, images, Docker volumes, and the installation directory:

```bash
sudo ./deploy/uninstall.sh --purge
```

You must type `PURGE` to confirm. This action is irreversible.

### 13.3 Unattended Purge

```bash
sudo ./deploy/uninstall.sh --purge --yes
```

Skips all confirmation prompts. Use with caution.

### 13.4 Uninstall Flags

| Flag | Description |
|---|---|
| `--purge` | Remove containers, images, volumes, and data |
| `--yes`, `-y` | Skip confirmation prompts |
| `--install-dir DIR` | Installation directory (default: `/opt/compass`) |

### 13.5 Cloud Teardown

**Azure:**
```bash
az group delete -n compass-rg --yes
```

**AWS:**
```bash
aws apprunner delete-service --service-arn <arn> --region us-east-1
aws rds delete-db-instance --db-instance-identifier <id> --skip-final-snapshot --region us-east-1
```

---

## 14. Troubleshooting

### 14.1 Diagnostic Commands

```bash
# Container status
docker compose ps

# Application logs (follow)
docker compose logs -f app

# Last 100 lines of app logs
docker compose logs --tail 100 app

# PostgreSQL logs
docker compose logs --tail 50 postgres

# Health check
curl -s http://localhost:3001/health | python3 -m json.tool

# Migration status
curl -s http://localhost:3001/health/migrations

# Database connectivity
docker compose exec postgres pg_isready -U compassadmin -d compass_dev

# Restart the application
docker compose -f docker-compose.yml -f docker-compose.prod.yml restart app

# Full restart (both containers)
docker compose -f docker-compose.yml -f docker-compose.prod.yml down
docker compose -f docker-compose.yml -f docker-compose.prod.yml up -d

# View environment variables in the container
docker compose exec app env | sort

# Check disk usage
docker system df
df -h /opt/compass
```

### 14.2 Common Issues

#### 1. "Docker not found"

**Cause:** Docker is not installed or not in PATH.

**Fix:** Let the installer install Docker automatically (say yes when prompted), or install manually: https://docs.docker.com/engine/install/

#### 2. "Docker Compose v2 not found"

**Cause:** Docker Compose plugin is not installed. Older `docker-compose` (v1) is not supported.

**Fix:** Install Docker Compose v2: https://docs.docker.com/compose/install/

#### 3. Health check never passes

**Cause:** App is still running migrations, or database connection failed.

**Fix:**
```bash
# Check if migrations are still running
docker compose logs --tail 20 app | grep -i migration

# Check database connection
docker compose exec postgres pg_isready -U compassadmin

# If postgres is down, restart it
docker compose up -d postgres
```

#### 4. "PostgreSQL did not become ready within 60 seconds"

**Cause:** PostgreSQL container failed to start or lacks resources.

**Fix:**
```bash
docker compose logs postgres
# Look for "out of memory" or "permission denied" errors
```

#### 5. Port 3001 is already in use

**Cause:** Another process is using port 3001.

**Fix:**
```bash
# Find what's using the port
ss -tlnp | grep 3001

# Change the port in .env
echo "COMPASS_PORT=3002" >> /opt/compass/.env
```

#### 6. "License has expired"

**Cause:** The license file is past its expiration date.

**Fix:** Contact your account representative for a new license file. Drop the new `.key` file into `/opt/compass/compass-license.key`. The server re-validates within 1 hour -- no restart required.

For cloud deployments, update the `COMPASS_LICENSE_B64` environment variable with the base64-encoded contents of the new license file and restart the service.

#### 7. License statuses

| Status | Condition | Behavior |
|---|---|---|
| `valid` | More than 30 days until expiration | Full access to all licensed modules |
| `warning` | 1-30 days until expiration | Full access, but a warning banner appears |
| `read_only` | Expired, within 14-day grace period | Existing data is readable, new assessments blocked |
| `locked_out` | Past the 14-day grace period | Application is locked. Replace the license to restore access. |

#### 8. AI features return errors

**Cause:** Missing or invalid Anthropic API key.

**Fix:** Add or update the key in `compass-config.yaml` or `.env`:
```bash
# In /opt/compass/.env
ANTHROPIC_API_KEY=sk-ant-api03-...
```
Then restart: `docker compose -f docker-compose.yml -f docker-compose.prod.yml restart app`

#### 9. "Cannot connect to proxy"

**Cause:** Proxy URL is misconfigured or the proxy is down.

**Fix:** Verify the proxy URL in `compass-config.yaml`. Ensure `localhost,127.0.0.1,postgres` is in `no_proxy`.

#### 10. Container keeps restarting

**Cause:** Crash loop, usually from misconfigured environment variables.

**Fix:**
```bash
docker compose logs --tail 50 app
# Look for the error message in the startup logs
```

Common causes: invalid `JWT_SECRET`, missing `POSTGRES_PASSWORD`, database hostname wrong.

#### 11. "ECONNREFUSED" in application logs

**Cause:** The app cannot reach PostgreSQL.

**Fix:** Verify PostgreSQL is running: `docker compose ps postgres`. The app connects to the PostgreSQL container via Docker's internal network (hostname `postgres`), not `localhost`.

#### 12. Slow first startup

**Cause:** First boot runs 93 database migrations. This is normal.

**Fix:** Wait 2-5 minutes. Monitor progress: `docker compose logs -f app | grep -i migration`

#### 13. "Permission denied" on config files

**Cause:** Docker container runs as a non-root user (UID 1001) and cannot read the bind-mounted config file.

**Fix:** Ensure `compass-config.yaml` has permissions `644`:
```bash
chmod 644 /opt/compass/compass-config.yaml
```

#### 14. Silent install exits immediately

**Cause:** Missing `--deploy-type` flag.

**Fix:** Add `--deploy-type docker` (or `azure`, `aws`, `airgap`):
```bash
sudo -E ./compass-setup.sh --deploy-type docker --silent
```

#### 15. Silent install says "missing COMPASS_ADMIN_*"

**Cause:** Required environment variables are not set or not exported.

**Fix:** Use `export` for all required variables, and use `sudo -E` to preserve the environment:
```bash
export COMPASS_ADMIN_EMAIL=admin@example.com
export COMPASS_ADMIN_PASSWORD='SecurePass!'
export COMPASS_ADMIN_NAME="Admin User"
export COMPASS_ADMIN_ORG="Acme Corp"
sudo -E ./compass-setup.sh --deploy-type docker --silent
```

#### 16. Smoke test fails on `/health/migrations`

**Cause:** Migrations are still running.

**Fix:** Wait a few minutes and re-run `./deploy/smoke-test.sh`. If it persists, check `docker compose logs app` for migration errors.

#### 17. Azure: "App did not respond within 5 minutes"

**Cause:** Container image pull failed, database connection issue, or slow migration.

**Fix:**
```bash
# View container logs
az webapp log tail -g compass-rg -n compass-a1b2c3

# Check settings
az webapp config appsettings list -g compass-rg -n compass-a1b2c3 -o table

# Restart
az webapp restart -g compass-rg -n compass-a1b2c3

# Nuclear option: tear down and start over
az group delete -n compass-rg --yes
sudo ./compass-setup.sh --deploy-type azure
```

#### 18. AWS: "App Runner service failed to start"

**Cause:** Container image not found, database connection issue, or configuration error.

**Fix:** Check the service logs in the AWS Console: App Runner > your service > Logs.

#### 19. Upgrade fails at health check

**Cause:** New version has a bug or requires database changes that failed.

**Fix:** Follow the rollback instructions printed by the upgrade script (see [Section 12.6](#126-rollback)).

#### 20. Backup fails with "container not running"

**Cause:** PostgreSQL container is stopped.

**Fix:**
```bash
cd /opt/compass
docker compose up -d postgres
./deploy/backup.sh
```

---

## Appendix A: Quick Command Reference

### Daily Operations

```bash
# Start DATA Compass
cd /opt/compass
docker compose -f docker-compose.yml -f docker-compose.prod.yml up -d

# Stop DATA Compass
docker compose -f docker-compose.yml -f docker-compose.prod.yml down

# Restart the application (preserves database)
docker compose -f docker-compose.yml -f docker-compose.prod.yml restart app

# View application logs
docker compose logs -f app

# Health check
curl -s http://localhost:3001/health

# Smoke tests
./deploy/smoke-test.sh
```

### Backup and Recovery

```bash
# Create backup
./deploy/backup.sh

# Create backup with 30-day retention
./deploy/backup.sh --retain 30

# List backups
./deploy/backup.sh --list

# Restore from backup
./deploy/backup.sh --restore /opt/compass/data/backups/compass_20260316_140000.dump
```

### User Management

```bash
# Create admin user (interactive password prompt)
./deploy/create-admin.sh --org "Acme Corp" --email admin@acme.com --name "Jane Smith"

# Create admin user (scripted)
./deploy/create-admin.sh --org "Acme Corp" --email admin@acme.com --name "Jane Smith" --password "SecurePass!"
```

### Upgrades

```bash
# Online upgrade (latest)
./deploy/upgrade.sh

# Pin specific version
./deploy/upgrade.sh --version 1.0.1

# Offline upgrade
./deploy/upgrade.sh --bundle compass-images-v1.0.1.tar.gz

# Dry run
./deploy/upgrade.sh --dry-run
```

### Uninstall

```bash
# Stop only (preserve data)
sudo ./deploy/uninstall.sh

# Full purge
sudo ./deploy/uninstall.sh --purge

# Unattended purge
sudo ./deploy/uninstall.sh --purge --yes
```

---

## Appendix B: File Locations

### Installation Directory (`/opt/compass`)

| Path | Description |
|---|---|
| `docker-compose.yml` | Base Docker Compose configuration |
| `docker-compose.prod.yml` | Production overlay (resource limits, logging, bind mounts) |
| `compass-config.yaml` | Application configuration (AI, proxy, features, branding) |
| `compass-config.yaml.template` | Configuration template (reference) |
| `.env` | Docker Compose secrets (POSTGRES_PASSWORD, JWT_SECRET, MFA_ENCRYPTION_KEY) |
| `compass-license.key` | License file (JWT format) |
| `data/uploads/` | User-uploaded files (CSV, Excel) |
| `data/exports/` | Generated reports (PDF, Excel) |
| `data/backups/` | Database backup files |
| `logs/` | Installation and application logs |
| `logs/install.log` | Installation log |
| `deploy/` | Deployment scripts |
| `deploy/install.sh` | 8-step setup wizard |
| `deploy/upgrade.sh` | Upgrade script |
| `deploy/backup.sh` | Backup script |
| `deploy/smoke-test.sh` | Post-deploy verification |
| `deploy/create-admin.sh` | Admin user creation |
| `deploy/uninstall.sh` | Uninstall script |
| `deploy/lib/` | Shared installer libraries |

### Docker Volumes

| Volume name | Mount point | Contents |
|---|---|---|
| `faircompass_postgres_data` | `/var/lib/postgresql/data` | PostgreSQL database files |
| `faircompass_uploads` | `/app/uploads` | User-uploaded files |
| `faircompass_exports` | `/app/exports` | Generated reports |
| `faircompass_backups` | `/app/backups` | Backup mount (prod overlay) |

### Container Names

| Container | Image | Purpose |
|---|---|---|
| `faircompass-app` | `ghcr.io/a-uppal/data-compass:1.0.0` | DATA Compass application |
| `faircompass-postgres` | `postgres:16-alpine` | PostgreSQL 16 database |

---

## Appendix C: Environment Variable Reference

Environment variables override values in `compass-config.yaml`. The `.env` file in the installation directory is read by Docker Compose and passed to the container.

### License

| YAML Path | Environment Variable | Description | Default |
|---|---|---|---|
| `license.path` | `COMPASS_LICENSE_PATH` | Path to license `.key` file | Auto-detected |
| `license.required` | `COMPASS_LICENSE_REQUIRED` | Enforce license validation (`true`/`false`) | `false` |
| `license.b64` | `COMPASS_LICENSE_B64` | Base64-encoded license JWT (for cloud deployments where file mounts are not available). If set, takes priority over `COMPASS_LICENSE_PATH` and file-based detection. | None |

### Server

| YAML Path | Environment Variable | Description | Default |
|---|---|---|---|
| `server.port` | `PORT` | Application port inside the container | `8080` |

> **Note:** The container listens on port 8080 internally. Docker maps it to host port 3001 via the `ports: "3001:8080"` directive in `docker-compose.yml`.

### Database

| YAML Path | Environment Variable | Description | Default |
|---|---|---|---|
| `database.host` | `PGHOST` | PostgreSQL hostname | `postgres` |
| `database.port` | `PGPORT` | PostgreSQL port | `5432` |
| `database.name` | `PGDATABASE` | Database name | `compass_dev` |
| `database.user` | `PGUSER` | Database user | `compassadmin` |
| `database.password` | `PGPASSWORD` | Database password | Set by installer |

### Authentication

| YAML Path | Environment Variable | Description | Default |
|---|---|---|---|
| `auth.jwt_secret` | `JWT_SECRET` | JWT signing secret (48 chars) | Auto-generated by installer |
| `auth.mfa_encryption_key` | `MFA_ENCRYPTION_KEY` | MFA TOTP encryption key (32 chars) | Auto-generated by installer |

### AI / LLM

| YAML Path | Environment Variable | Description | Default |
|---|---|---|---|
| `ai.api_key` | `ANTHROPIC_API_KEY` | Anthropic API key | None |
| `ai.model` | `ANTHROPIC_MODEL` | Claude model name | `claude-sonnet-4-5-20250929` |
| `ai.daily_budget_usd` | `LLM_DAILY_BUDGET_USD` | Daily spending cap in USD | `10.0` |

### Logging

| YAML Path | Environment Variable | Description | Default |
|---|---|---|---|
| `logging.format` | `LOG_FORMAT` | Log format (`json` or `text`) | `json` |
| `logging.level` | `LOG_LEVEL` | Log level (`debug`, `info`, `warn`, `error`) | `info` |

### Branding

| YAML Path | Environment Variable | Description | Default |
|---|---|---|---|
| `branding.product_name` | `PRODUCT_NAME` | Product name in the UI | `DATA Compass` |
| `branding.customer_name` | `CUSTOMER_NAME` | Customer name in the header | None |

### Proxy

| YAML Path | Environment Variable | Description | Default |
|---|---|---|---|
| `proxy.http_proxy` | `HTTP_PROXY` | HTTP proxy URL | None |
| `proxy.https_proxy` | `HTTPS_PROXY` | HTTPS proxy URL | None |
| `proxy.no_proxy` | `NO_PROXY` | Comma-separated no-proxy list | `localhost,127.0.0.1,postgres` |

### Security

| YAML Path | Environment Variable | Description | Default |
|---|---|---|---|
| `security.trust_proxy` | `TRUST_PROXY` | Trust X-Forwarded-* headers | `true` |
| — | `ENABLE_HSTS` | HTTP Strict Transport Security | Not set (disabled) |

### Secrets Provider

| YAML Path | Environment Variable | Description | Default |
|---|---|---|---|
| `secrets.provider` | `SECRETS_PROVIDER` | Secrets backend (`environment`, `azure`, `file`, `vault`) | `environment` |

### Installer

| YAML Path | Environment Variable | Description | Default |
|---|---|---|---|
| `install.download_url` | `COMPASS_DOWNLOAD_URL` | Deploy bundle download URL | `https://compassfordata.com/releases` |
| `install.image` | `COMPASS_IMAGE` | Docker image reference | `ghcr.io/a-uppal/data-compass:1.0.0` |
