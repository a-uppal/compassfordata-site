#!/usr/bin/env bash
# =============================================================================
# DATA Compass - Uninstall Script (DC-1452)
# =============================================================================
# Standalone uninstall script. Can stop containers or fully purge data.
#
# Usage:
#   sudo ./deploy/uninstall.sh                  # Interactive (prompts)
#   sudo ./deploy/uninstall.sh --yes            # Skip confirmation
#   sudo ./deploy/uninstall.sh --purge          # Remove data, volumes, images
#   sudo ./deploy/uninstall.sh --purge --yes    # Full unattended purge
#
# Exit codes:
#   0 - Uninstall successful
#   1 - Error or cancelled
# =============================================================================

set -euo pipefail

# ---------------------------------------------------------------------------
# Source shared libraries if available
# ---------------------------------------------------------------------------
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LIB_DIR="${SCRIPT_DIR}/lib"

if [[ -d "$LIB_DIR" && -f "$LIB_DIR/common.sh" ]]; then
  . "$LIB_DIR/common.sh"
else
  # Minimal fallback
  if [[ -n "${NO_COLOR:-}" ]] || [ ! -t 1 ]; then
    RED=''; GREEN=''; YELLOW=''; BOLD=''; NC=''
  else
    RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BOLD='\033[1m'; NC='\033[0m'
  fi
  ok()   { echo -e "  ${GREEN}[OK]${NC} $1"; }
  warn() { echo -e "  ${YELLOW}[WARN]${NC} $1"; }
  fail() { echo -e "  ${RED}[FAIL]${NC} $1"; }
  info() { echo -e "  $1"; }
fi

# ---------------------------------------------------------------------------
# Arguments
# ---------------------------------------------------------------------------
PURGE=false
YES=false
INSTALL_DIR="${COMPASS_INSTALL_DIR:-/opt/compass}"

while [[ $# -gt 0 ]]; do
  case "$1" in
    --purge)       PURGE=true; shift ;;
    --yes|-y)      YES=true; shift ;;
    --install-dir) INSTALL_DIR="$2"; shift 2 ;;
    -h|--help)
      echo "Usage: $0 [--purge] [--yes] [--install-dir <path>]"
      echo ""
      echo "Options:"
      echo "  --purge          Remove containers, images, volumes, AND data"
      echo "  --yes, -y        Skip confirmation prompts"
      echo "  --install-dir    Installation directory (default: /opt/compass)"
      echo "  -h, --help       Show this help"
      echo ""
      echo "Without --purge: stops containers but preserves data and images."
      echo "With --purge: removes everything including database volumes."
      exit 0
      ;;
    *) echo -e "${RED}Unknown option: $1${NC}"; exit 1 ;;
  esac
done

COMPOSE_FILES="-f docker-compose.yml -f docker-compose.prod.yml"

echo -e "${BOLD}DATA Compass Uninstall${NC}"
echo "Install dir: ${INSTALL_DIR}"
echo "Mode:        $(if $PURGE; then echo 'PURGE (remove everything)'; else echo 'STOP (preserve data)'; fi)"
echo ""

# ---------------------------------------------------------------------------
# Verify Docker is available
# ---------------------------------------------------------------------------
if ! command -v docker &>/dev/null; then
  warn "Docker not found. Nothing to stop."
  if $PURGE && [[ -d "$INSTALL_DIR" ]]; then
    if $YES || { echo -n "Remove ${INSTALL_DIR}? [y/N]: " && read -r r && [[ "$r" =~ ^[Yy]$ ]]; }; then
      rm -rf "$INSTALL_DIR"
      ok "Removed ${INSTALL_DIR}"
    fi
  fi
  exit 0
fi

# Find compose directory
CD_DIR="$INSTALL_DIR"
if [[ -f "$SCRIPT_DIR/../docker-compose.yml" ]]; then
  CD_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
fi

if [[ ! -f "$CD_DIR/docker-compose.yml" ]]; then
  warn "docker-compose.yml not found in ${CD_DIR}"
  exit 0
fi

# ---------------------------------------------------------------------------
# Stop mode (default)
# ---------------------------------------------------------------------------
if [[ "$PURGE" == false ]]; then
  if $YES; then
    info "Stopping containers..."
  else
    echo -n "  Stop all DATA Compass containers? [y/N]: "
    read -r answer
    if [[ ! "$answer" =~ ^[Yy]$ ]]; then
      info "Cancelled."
      exit 0
    fi
  fi

  (cd "$CD_DIR" && docker compose ${COMPOSE_FILES} down 2>/dev/null) || \
    (cd "$CD_DIR" && docker compose down 2>/dev/null) || true

  ok "Containers stopped. Data preserved in ${INSTALL_DIR}/data/"
  info "To restart: cd ${INSTALL_DIR} && docker compose ${COMPOSE_FILES} up -d"
  exit 0
fi

# ---------------------------------------------------------------------------
# Purge mode
# ---------------------------------------------------------------------------
if $YES; then
  info "Purging all DATA Compass data, containers, and images..."
else
  warn "This will PERMANENTLY DELETE all data, containers, images, and volumes!"
  echo ""
  echo -n "  Type 'PURGE' to confirm: "
  read -r confirm
  if [[ "$confirm" != "PURGE" ]]; then
    info "Purge cancelled (expected 'PURGE')."
    exit 0
  fi
fi

# Stop and remove containers, volumes, images
(cd "$CD_DIR" && docker compose ${COMPOSE_FILES} down -v --rmi all 2>/dev/null) || \
  (cd "$CD_DIR" && docker compose down -v --rmi all 2>/dev/null) || true

ok "Containers, volumes, and images removed"

# Remove installation directory
if [[ -d "$INSTALL_DIR" ]]; then
  if $YES; then
    rm -rf "$INSTALL_DIR"
    ok "Removed ${INSTALL_DIR}"
  else
    echo -n "  Also remove ${INSTALL_DIR}? [y/N]: "
    read -r answer
    if [[ "$answer" =~ ^[Yy]$ ]]; then
      rm -rf "$INSTALL_DIR"
      ok "Removed ${INSTALL_DIR}"
    else
      info "Kept ${INSTALL_DIR}"
    fi
  fi
fi

# Remove marker file
rm -f "${INSTALL_DIR}/.compass-installed" 2>/dev/null || true

echo ""
ok "DATA Compass has been uninstalled."
