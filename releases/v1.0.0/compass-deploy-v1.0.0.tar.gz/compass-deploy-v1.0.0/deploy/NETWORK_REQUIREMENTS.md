# DATA Compass - Network Requirements (DC-1282)

This document describes the network configuration required for a DATA Compass deployment. Provide this to your IT/network team during installation planning.

---

## 1. Firewall Rules

### Inbound

| Port | Protocol | Source | Description |
|------|----------|--------|-------------|
| 443  | TCP/HTTPS | End users | Web application (configurable via `server.port` in compass-config.yaml) |
| 22   | TCP/SSH   | Admin IPs only | Server administration (optional, restrict to bastion/VPN) |

### Outbound (Required)

| Destination | Port | Protocol | Description |
|-------------|------|----------|-------------|
| `api.anthropic.com` | 443 | HTTPS | Claude AI API for Bridge Intelligence, semantic analysis, and interview synthesis |
| `eutils.ncbi.nlm.nih.gov` | 443 | HTTPS | PubMed/E-utilities for literature-backed AI citations |
| `data.bioontology.org` | 443 | HTTPS | BioPortal ontology lookup and validation |

### Outbound (Optional - by integration)

| Destination | Port | Protocol | Description |
|-------------|------|----------|-------------|
| Customer Databricks workspace | 443 | HTTPS | Databricks Unity Catalog integration |
| Customer Collibra instance | 443 | HTTPS | Collibra data governance integration |
| Customer Veeva Vault | 443 | HTTPS | Veeva QMS/CDMS/RIM integration |
| Customer Snowflake account | 443 | HTTPS | Snowflake data platform integration |
| Customer Stardog instance | 5820 | HTTPS | Stardog knowledge graph integration |

### Internal (Container Network)

| Source | Destination | Port | Protocol | Description |
|--------|-------------|------|----------|-------------|
| app | postgres | 5432 | TCP | PostgreSQL database (Docker internal network) |

> **Note:** The PostgreSQL port does NOT need to be exposed to the host network in production. Docker's internal network handles container-to-container communication.

---

## 2. Data Flow Guarantees

DATA Compass is designed for on-premises deployment with strict data boundaries:

- **Only schema metadata** (column names, data types, statistical summaries) is sent to the AI API. Raw data values never leave the server.
- **Ontology files** (OWL, TTL, RDF) are parsed and analyzed locally. Only structural summaries are sent for semantic analysis.
- **All assessment data** (scores, reports, ALCOA+ evaluations) is stored in the local PostgreSQL database.
- **File uploads** (CSV, Excel) are processed on the local server and stored in local volumes.
- **No telemetry** or usage data is sent to any external service.

### Data Classification by Destination

| Destination | Data Sent | Data NOT Sent |
|-------------|-----------|---------------|
| Anthropic API | Schema names, column types, statistical summaries, ontology structure | Raw data values, PII, file contents |
| PubMed API | Search terms (topic keywords) | Organization data, assessment results |
| BioPortal API | Ontology class names for lookup | Full ontology files, assessment data |

---

## 3. Proxy Configuration

If outbound traffic must pass through an HTTP proxy, configure it in `compass-config.yaml`:

```yaml
proxy:
  http_proxy: "http://proxy.corp.example.com:8080"
  https_proxy: "http://proxy.corp.example.com:8080"
  no_proxy: "localhost,127.0.0.1,postgres"
```

This sets the standard `HTTP_PROXY`, `HTTPS_PROXY`, and `NO_PROXY` environment variables inside the container. All outbound HTTP clients (AI API, PubMed, BioPortal, integrations) respect these variables.

**Important:** Always include `localhost,127.0.0.1,postgres` in `no_proxy` to prevent internal traffic from being routed through the proxy.

---

## 4. TLS Certificate Requirements

### Option A: Reverse Proxy (Recommended)

Place a reverse proxy (nginx, Apache, HAProxy, AWS ALB, Azure Application Gateway) in front of DATA Compass:

```
Client --> Reverse Proxy (TLS termination, port 443) --> DATA Compass (HTTP, port 3001)
```

- Install your organization's TLS certificate on the reverse proxy
- Set `TRUST_PROXY=true` in compass-config.yaml (default)
- HSTS headers are automatically added by the application in production mode

### Option B: Direct TLS

DATA Compass can terminate TLS directly:

```yaml
# compass-config.yaml
tls:
  cert_path: /app/certs/server.crt
  key_path: /app/certs/server.key
```

Mount certificate files into the container:

```yaml
# docker-compose.prod.yml (additional volume)
volumes:
  - ./certs/server.crt:/app/certs/server.crt:ro
  - ./certs/server.key:/app/certs/server.key:ro
```

**Certificate requirements:**
- PEM format (.crt / .key)
- RSA 2048-bit minimum or ECDSA P-256
- Include full chain (server cert + intermediates) in the .crt file
- Self-signed certificates are supported but clients may need to trust the CA

---

## 5. DNS Requirements

- The server must resolve the hostnames listed in the outbound firewall rules
- If using a private DNS server, ensure `api.anthropic.com`, `eutils.ncbi.nlm.nih.gov`, and `data.bioontology.org` are resolvable
- The container uses the host's DNS configuration by default

For custom DNS servers, add to `docker-compose.prod.yml`:

```yaml
services:
  app:
    dns:
      - 10.0.0.53
      - 10.0.0.54
```

---

## 6. Bandwidth Estimates

### Per-Request

| Operation | Outbound | Inbound | Notes |
|-----------|----------|---------|-------|
| Bridge AI synthesis | 2-5 KB | 3-10 KB | Schema summary + AI response |
| Semantic ontology analysis | 5-15 KB | 10-30 KB | Ontology structure summary |
| Literature search | 1-2 KB | 5-20 KB | PubMed API query + results |
| BioPortal lookup | < 1 KB | 2-5 KB | Class name validation |

### Daily Estimates (per active user)

| Usage Level | Outbound | Inbound |
|-------------|----------|---------|
| Light (5-10 assessments/day) | 50-100 KB | 100-300 KB |
| Moderate (20-50 assessments/day) | 200-500 KB | 500 KB - 1.5 MB |
| Heavy (100+ assessments/day) | 1-3 MB | 3-10 MB |

> **Note:** These estimates are for AI API traffic only. Intra-network traffic (database, file uploads) is local and does not traverse the firewall.

---

## 7. Health Check Endpoints

Use these endpoints for load balancer or monitoring configuration:

| Endpoint | Method | Expected Response | Purpose |
|----------|--------|-------------------|---------|
| `/health` | GET | 200 OK | Basic liveness check |
| `/health/ready` | GET | 200 OK | Full readiness (includes DB) |

Both endpoints return JSON:

```json
{
  "ok": true,
  "env": "production",
  "version": "1.0.0",
  "services": {
    "database": { "healthy": true },
    "storage": { "healthy": true, "backend": "postgres" },
    "schema": { "healthy": true }
  }
}
```
