#!/usr/bin/env bash
# =============================================================================
# DATA Compass - Admin User Creation Script (DC-1281)
# =============================================================================
# Creates an initial admin user and organization for customer deployments.
#
# Usage:
#   ./deploy/create-admin.sh --org "Acme Corp" --email admin@acme.com --name "Admin User"
#   ./deploy/create-admin.sh --org "Acme Corp" --email admin@acme.com --password "s3cret!" --name "Admin User"
#
# If --password is omitted, you will be prompted interactively.
# =============================================================================

set -euo pipefail

if [[ -n "${NO_COLOR:-}" ]]; then
  RED=''; GREEN=''; YELLOW=''; NC=''
else
  RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'
fi

ORG=""
EMAIL=""
PASSWORD=""
NAME=""

usage() {
  echo "Usage: $0 --org <org_name> --email <email> [--password <password>] --name <full_name>"
  echo ""
  echo "Options:"
  echo "  --org        Organization name (e.g., 'Acme Corp')"
  echo "  --email      Admin email address"
  echo "  --password   Admin password (prompted if omitted)"
  echo "  --name       Admin full name"
  exit 1
}

# Parse arguments
while [[ $# -gt 0 ]]; do
  case "$1" in
    --org)      ORG="$2"; shift 2 ;;
    --email)    EMAIL="$2"; shift 2 ;;
    --password) PASSWORD="$2"; shift 2 ;;
    --name)     NAME="$2"; shift 2 ;;
    -h|--help)  usage ;;
    *)          echo -e "${RED}Unknown option: $1${NC}"; usage ;;
  esac
done

# Validate required args
if [[ -z "$ORG" || -z "$EMAIL" || -z "$NAME" ]]; then
  echo -e "${RED}Error: --org, --email, and --name are required.${NC}"
  usage
fi

# Validate email format
if ! echo "$EMAIL" | grep -qE '^[^@[:space:]]+@[^@[:space:]]+\.[^@[:space:]]+$'; then
  echo -e "${RED}Error: Invalid email format: ${EMAIL}${NC}"
  exit 1
fi

# Prompt for password if not provided
if [[ -z "$PASSWORD" ]]; then
  echo -n "Enter admin password (min 8 chars): "
  read -rs PASSWORD
  echo ""
  if [[ ${#PASSWORD} -lt 8 ]]; then
    echo -e "${RED}Error: Password must be at least 8 characters.${NC}"
    exit 1
  fi
  echo -n "Confirm password: "
  read -rs PASSWORD_CONFIRM
  echo ""
  if [[ "$PASSWORD" != "$PASSWORD_CONFIRM" ]]; then
    echo -e "${RED}Error: Passwords do not match.${NC}"
    exit 1
  fi
fi

echo -e "${YELLOW}Creating admin user...${NC}"
echo "  Organization: $ORG"
echo "  Email:        $EMAIL"
echo "  Name:         $NAME"

# Determine script directory and project root
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"

SEED_EXIT=0

# Detection order: Docker deployment → compiled JS on host → ts-node dev
if [[ -f "$PROJECT_ROOT/docker-compose.yml" ]] && docker compose ps app 2>/dev/null | grep -q "Up"; then
  # Production Docker deployment: exec into the running app container
  # Password passed via env var to avoid exposure in process list
  docker compose -f "$PROJECT_ROOT/docker-compose.yml" -f "$PROJECT_ROOT/docker-compose.prod.yml" exec \
    -e ADMIN_PASSWORD="$PASSWORD" \
    -e ADMIN_ORG="$ORG" \
    -e ADMIN_EMAIL="$EMAIL" \
    -e ADMIN_NAME="$NAME" \
    app sh -c 'node dist/db/seedPocUsers.js --org "$ADMIN_ORG" --email "$ADMIN_EMAIL" --password "$ADMIN_PASSWORD" --name "$ADMIN_NAME"' \
    || SEED_EXIT=$?
elif [[ -f "$PROJECT_ROOT/dist/server/db/seedPocUsers.js" ]]; then
  # Host development: compiled JS available
  export ADMIN_PASSWORD="$PASSWORD"
  node "$PROJECT_ROOT/dist/server/db/seedPocUsers.js" \
    --org "$ORG" --email "$EMAIL" --name "$NAME" || SEED_EXIT=$?
  unset ADMIN_PASSWORD
elif [[ -f "$PROJECT_ROOT/server/db/seedPocUsers.ts" ]]; then
  # Host development: source TypeScript available
  export ADMIN_PASSWORD="$PASSWORD"
  npx ts-node "$PROJECT_ROOT/server/db/seedPocUsers.ts" \
    --org "$ORG" --email "$EMAIL" --name "$NAME" || SEED_EXIT=$?
  unset ADMIN_PASSWORD
else
  echo -e "${RED}Error: Cannot find seedPocUsers script.${NC}"
  echo "  Ensure the app container is running (docker compose ps)"
  echo "  or that you are running from the source tree."
  exit 1
fi

if [[ $SEED_EXIT -eq 0 ]]; then
  echo -e "${GREEN}Admin user created successfully.${NC}"
else
  echo -e "${RED}Failed to create admin user. Check logs above.${NC}"
  exit 1
fi
