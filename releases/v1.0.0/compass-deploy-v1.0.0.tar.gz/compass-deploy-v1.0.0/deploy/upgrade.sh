#!/usr/bin/env bash
# =============================================================================
# DATA Compass - Upgrade Script
# =============================================================================
# Upgrades DATA Compass to a new version with automatic backup and rollback
# instructions. Designed for customer IT teams.
#
# Usage:
#   ./deploy/upgrade.sh                             # Online (pull from registry)
#   ./deploy/upgrade.sh --bundle compass-images.tar.gz  # Offline
#   ./deploy/upgrade.sh --dry-run                   # Preview without changes
#
# Steps performed:
#   1. Pre-flight checks (Docker, running containers)
#   2. Capture current image tag (for rollback)
#   3. Auto-backup database
#   4. Load/pull new Docker images
#   5. Restart services with new images
#   6. Wait for health
#   7. Run smoke tests
#
# On failure, prints rollback instructions.
# =============================================================================

set -euo pipefail

# ---------------------------------------------------------------------------
# Colors & helpers
# ---------------------------------------------------------------------------
if [[ -n "${NO_COLOR:-}" ]] || [ ! -t 1 ]; then
  RED=''; GREEN=''; YELLOW=''; BLUE=''; BOLD=''; NC=''
else
  RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
  BLUE='\033[0;34m'; BOLD='\033[1m'; NC='\033[0m'
fi

step_num=0
step() {
  step_num=$((step_num + 1))
  echo ""
  echo -e "${BLUE}${BOLD}=== Step ${step_num}: $1 ===${NC}"
}

ok()   { echo -e "  ${GREEN}[OK]${NC} $1"; }
warn() { echo -e "  ${YELLOW}[WARN]${NC} $1"; }
fail() { echo -e "  ${RED}[FAIL]${NC} $1"; }
info() { echo -e "  $1"; }

# ---------------------------------------------------------------------------
# Arguments
# ---------------------------------------------------------------------------
BUNDLE=""
DRY_RUN=false
TARGET_VERSION=""
COMPASS_PORT="${COMPASS_PORT:-3001}"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
INSTALL_DIR="${COMPASS_INSTALL_DIR:-/opt/compass}"

while [[ $# -gt 0 ]]; do
  case "$1" in
    --bundle)   BUNDLE="$2"; shift 2 ;;
    --version)  TARGET_VERSION="$2"; shift 2 ;;
    --dry-run)  DRY_RUN=true; shift ;;
    --install-dir) INSTALL_DIR="$2"; shift 2 ;;
    -h|--help)
      echo "Usage: $0 [--bundle <images.tar.gz>] [--version <VERSION>] [--dry-run] [--install-dir <path>]"
      echo ""
      echo "Options:"
      echo "  --bundle FILE     Offline: load images from tarball"
      echo "  --version VERSION Pin a specific version (e.g., 1.0.1)"
      echo "  --dry-run         Preview upgrade steps without executing"
      echo "  --install-dir DIR Installation directory (default: /opt/compass)"
      exit 0
      ;;
    *) echo -e "${RED}Unknown option: $1${NC}"; exit 1 ;;
  esac
done

COMPOSE_FILES="-f docker-compose.yml -f docker-compose.prod.yml"

echo -e "${BOLD}DATA Compass Upgrade${NC}"
echo "Install dir: ${INSTALL_DIR}"
echo "Dry run:     ${DRY_RUN}"
if [ -n "$TARGET_VERSION" ]; then
  echo "Version:     ${TARGET_VERSION}"
fi
if [ -n "$BUNDLE" ]; then
  echo "Bundle:      ${BUNDLE}"
fi
echo ""

# ==========================================================================
# Step 1: Pre-flight checks
# ==========================================================================
step "Pre-flight Checks"

if ! command -v docker &>/dev/null; then
  fail "Docker not found"
  exit 1
fi
ok "Docker installed"

if ! docker compose version &>/dev/null; then
  fail "Docker Compose v2 not found"
  exit 1
fi
ok "Docker Compose available"

cd "$INSTALL_DIR"

if ! docker compose ps --format '{{.Name}}' 2>/dev/null | grep -q .; then
  fail "No running containers found in ${INSTALL_DIR}"
  info "Is DATA Compass installed? Run deploy/install.sh first."
  exit 1
fi
ok "Running containers detected"

if [ -n "$BUNDLE" ] && [ ! -f "$BUNDLE" ]; then
  fail "Bundle file not found: $BUNDLE"
  exit 1
fi

# ==========================================================================
# Step 2: Capture current image for rollback
# ==========================================================================
step "Capture Current Image"

PREVIOUS_IMAGE=$(docker compose config --images 2>/dev/null | grep -v postgres | head -1 || echo "unknown")
PREVIOUS_TAG=$(docker inspect --format='{{index .RepoDigests 0}}' "$PREVIOUS_IMAGE" 2>/dev/null || echo "$PREVIOUS_IMAGE")

ok "Current app image: ${PREVIOUS_IMAGE}"
info "This tag will be used for rollback if needed."

if $DRY_RUN; then
  info "[DRY RUN] Would save current image info for rollback"
fi

# ==========================================================================
# Step 3: Auto-backup database
# ==========================================================================
step "Database Backup"

BACKUP_SCRIPT="${INSTALL_DIR}/deploy/backup.sh"
if [ ! -f "$BACKUP_SCRIPT" ]; then
  BACKUP_SCRIPT="${SCRIPT_DIR}/backup.sh"
fi

if [ -f "$BACKUP_SCRIPT" ]; then
  if $DRY_RUN; then
    info "[DRY RUN] Would run: bash ${BACKUP_SCRIPT}"
  else
    bash "$BACKUP_SCRIPT" && ok "Pre-upgrade backup complete" || {
      fail "Backup failed. Aborting upgrade for safety."
      exit 1
    }
  fi
else
  warn "backup.sh not found. Skipping auto-backup."
  warn "Strongly recommended: manually backup before proceeding."
fi

# ==========================================================================
# Step 4: Load/pull new images
# ==========================================================================
step "Load New Images"

# If --version was specified, update .env so docker-compose uses the pinned version
if [ -n "$TARGET_VERSION" ]; then
  ENV_FILE="${INSTALL_DIR}/.env"
  if [ -f "$ENV_FILE" ]; then
    if grep -q '^COMPASS_VERSION=' "$ENV_FILE"; then
      if $DRY_RUN; then
        info "[DRY RUN] Would update COMPASS_VERSION=${TARGET_VERSION} in ${ENV_FILE}"
      else
        sed -i "s/^COMPASS_VERSION=.*/COMPASS_VERSION=${TARGET_VERSION}/" "$ENV_FILE"
        ok "Updated COMPASS_VERSION=${TARGET_VERSION} in .env"
      fi
    else
      if $DRY_RUN; then
        info "[DRY RUN] Would append COMPASS_VERSION=${TARGET_VERSION} to ${ENV_FILE}"
      else
        echo "COMPASS_VERSION=${TARGET_VERSION}" >> "$ENV_FILE"
        ok "Added COMPASS_VERSION=${TARGET_VERSION} to .env"
      fi
    fi
  else
    if $DRY_RUN; then
      info "[DRY RUN] Would create ${ENV_FILE} with COMPASS_VERSION=${TARGET_VERSION}"
    else
      echo "COMPASS_VERSION=${TARGET_VERSION}" > "$ENV_FILE"
      ok "Created .env with COMPASS_VERSION=${TARGET_VERSION}"
    fi
  fi
fi

if [ -n "$BUNDLE" ]; then
  if $DRY_RUN; then
    info "[DRY RUN] Would run: docker load < ${BUNDLE}"
  else
    info "Loading images from bundle..."
    docker load < "$BUNDLE"
    ok "Images loaded from ${BUNDLE}"
  fi
else
  if $DRY_RUN; then
    info "[DRY RUN] Would run: docker compose pull"
  else
    info "Pulling latest images from registry..."
    docker compose pull
    ok "Images pulled from registry"
  fi
fi

# ==========================================================================
# Step 5: Restart services
# ==========================================================================
step "Restart Services"

if $DRY_RUN; then
  info "[DRY RUN] Would run: docker compose ${COMPOSE_FILES} up -d --no-build"
else
  docker compose ${COMPOSE_FILES} up -d --no-build
  ok "Services restarted with new images"
fi

# ==========================================================================
# Step 6: Wait for health
# ==========================================================================
step "Health Check"

if $DRY_RUN; then
  info "[DRY RUN] Would poll http://localhost:${COMPASS_PORT}/health/ready"
else
  info "Waiting for application to become ready..."

  RETRIES=60
  until curl -sf "http://localhost:${COMPASS_PORT}/health/ready" &>/dev/null; do
    RETRIES=$((RETRIES - 1))
    if [ $RETRIES -le 0 ]; then
      fail "Application did not become ready within 120 seconds"
      echo ""
      echo -e "${RED}${BOLD}UPGRADE MAY HAVE FAILED${NC}"
      echo ""
      echo -e "${YELLOW}Rollback instructions:${NC}"
      echo "  1. docker compose ${COMPOSE_FILES} down"
      echo "  2. Restore backup: ./deploy/backup.sh --restore <latest-backup>"
      echo "  3. Load previous images (if saved)"
      echo "  4. docker compose ${COMPOSE_FILES} up -d"
      echo ""
      echo "  Previous image: ${PREVIOUS_IMAGE}"
      echo "  Check logs:     docker compose logs --tail 100 app"
      exit 1
    fi
    sleep 2
  done

  ok "Application is healthy"
fi

# ==========================================================================
# Step 7: Smoke tests
# ==========================================================================
step "Smoke Tests"

SMOKE_SCRIPT="${INSTALL_DIR}/deploy/smoke-test.sh"
if [ ! -f "$SMOKE_SCRIPT" ]; then
  SMOKE_SCRIPT="${SCRIPT_DIR}/smoke-test.sh"
fi

if [ -f "$SMOKE_SCRIPT" ]; then
  if $DRY_RUN; then
    info "[DRY RUN] Would run: bash ${SMOKE_SCRIPT} --url http://localhost:${COMPASS_PORT}"
  else
    bash "$SMOKE_SCRIPT" --url "http://localhost:${COMPASS_PORT}" && ok "Smoke tests passed" || {
      warn "Some smoke tests failed. Review output above."
      warn "The application may still be functional. Check logs."
    }
  fi
else
  warn "smoke-test.sh not found. Skipping automated tests."
  info "Manual verification: curl -s http://localhost:${COMPASS_PORT}/health"
fi

# ==========================================================================
# Summary
# ==========================================================================
echo ""
if $DRY_RUN; then
  echo -e "${YELLOW}${BOLD}Dry run complete. No changes were made.${NC}"
  echo "Remove --dry-run to perform the actual upgrade."
else
  echo -e "${GREEN}${BOLD}Upgrade complete!${NC}"
  echo ""
  echo -e "  Previous image: ${PREVIOUS_IMAGE}"
  echo -e "  Health:         curl http://localhost:${COMPASS_PORT}/health"
  echo -e "  Logs:           docker compose logs -f app"
  echo ""
  echo -e "  ${YELLOW}If issues arise:${NC}"
  echo "    1. docker compose ${COMPOSE_FILES} down"
  echo "    2. ./deploy/backup.sh --restore <pre-upgrade-backup>"
  echo "    3. docker compose ${COMPOSE_FILES} up -d"
fi
