#!/usr/bin/env bash
# =============================================================================
# DATA Compass - Interactive Installer (DC-1277, DC-1446)
# =============================================================================
# 8-step interactive installer for customer IT teams.
# This is a thin orchestrator that sources deploy/lib/*.sh for all logic.
#
# Usage:
#   sudo ./deploy/install.sh
#   sudo ./deploy/install.sh --install-dir /opt/compass --offline
#   sudo ./deploy/install.sh --silent                    # Unattended (DC-1450)
#   sudo ./deploy/install.sh --dry-run                   # Preview only (DC-1450)
#   ./deploy/install.sh --version                        # Print version (DC-1450)
#
# Silent mode env vars (required when --silent):
#   COMPASS_ADMIN_EMAIL, COMPASS_ADMIN_PASSWORD,
#   COMPASS_ADMIN_NAME, COMPASS_ADMIN_ORG
# Optional: COMPASS_AI_KEY, COMPASS_PROXY_URL, COMPASS_INSTALL_DOCKER, COMPASS_LICENSE_FILE
# =============================================================================

set -euo pipefail

# ---------------------------------------------------------------------------
# Source shared libraries
# ---------------------------------------------------------------------------
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LIB_DIR="${SCRIPT_DIR}/lib"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"

if [[ -d "$LIB_DIR" ]]; then
  . "$LIB_DIR/common.sh"
  . "$LIB_DIR/logging.sh"
  . "$LIB_DIR/preflight.sh"
  . "$LIB_DIR/config-gen.sh"
  . "$LIB_DIR/docker-install.sh"
  . "$LIB_DIR/rollback.sh"
else
  # Fallback: minimal colors if lib/ not found (shouldn't happen in normal use)
  if [[ -n "${NO_COLOR:-}" ]]; then
    RED=''; GREEN=''; YELLOW=''; BLUE=''; BOLD=''; NC=''
  else
    RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
    BLUE='\033[0;34m'; BOLD='\033[1m'; NC='\033[0m'
  fi
  ok()   { echo -e "  ${GREEN}[OK]${NC} $1"; }
  warn() { echo -e "  ${YELLOW}[WARN]${NC} $1"; }
  fail() { echo -e "  ${RED}[FAIL]${NC} $1"; exit 1; }
  info() { echo -e "  $1"; }
  step() { echo -e "\n${BLUE}${BOLD}=== Step $1 ===${NC}"; }
fi

# ---------------------------------------------------------------------------
# Defaults & argument parsing
# ---------------------------------------------------------------------------
INSTALL_DIR="/opt/compass"
OFFLINE=false
CONFIG_FILE=""
LICENSE_FILE=""
COMPASS_SILENT="${COMPASS_SILENT:-false}"
COMPASS_DRY_RUN="${COMPASS_DRY_RUN:-false}"
COMPASS_PORT="${COMPASS_PORT:-3001}"
VERSION=$(common_get_version "$PROJECT_ROOT" 2>/dev/null || echo "0.0.0")

while [[ $# -gt 0 ]]; do
  case "$1" in
    --install-dir) INSTALL_DIR="$2"; shift 2 ;;
    --offline)     OFFLINE=true; shift ;;
    --config)      CONFIG_FILE="$2"; shift 2 ;;
    --license)     LICENSE_FILE="$2"; shift 2 ;;
    --silent)      COMPASS_SILENT=true; shift ;;
    --dry-run)     COMPASS_DRY_RUN=true; shift ;;
    --version)     echo "DATA Compass Installer v${VERSION}"; exit 0 ;;
    -h|--help)
      echo "Usage: $0 [OPTIONS]"
      echo ""
      echo "Options:"
      echo "  --install-dir <path>  Installation directory (default: /opt/compass)"
      echo "  --offline             Expect bundled Docker images"
      echo "  --config <yaml>       Use provided config file"
      echo "  --license <path>      Path to compass-license.key file"
      echo "  --silent              Unattended install (reads COMPASS_* env vars)"
      echo "  --dry-run             Preview install plan without modifying system"
      echo "  --version             Print version and exit"
      echo "  -h, --help            Show this help"
      echo ""
      echo "Silent mode env vars (required):"
      echo "  COMPASS_ADMIN_EMAIL, COMPASS_ADMIN_PASSWORD,"
      echo "  COMPASS_ADMIN_NAME, COMPASS_ADMIN_ORG"
      echo "Optional: COMPASS_AI_KEY, COMPASS_PROXY_URL, COMPASS_INSTALL_DOCKER, COMPASS_LICENSE_FILE"
      exit 0
      ;;
    *) echo -e "${RED}Unknown option: $1${NC}"; exit 1 ;;
  esac
done

# Re-initialize colors (COMPASS_SILENT may have changed)
if [[ -d "$LIB_DIR" ]]; then
  common_init_colors
fi

# Validate silent mode has required env vars
if [[ "$COMPASS_SILENT" == true ]]; then
  missing=""
  [[ -z "${COMPASS_ADMIN_EMAIL:-}" ]] && missing="$missing COMPASS_ADMIN_EMAIL"
  [[ -z "${COMPASS_ADMIN_PASSWORD:-}" ]] && missing="$missing COMPASS_ADMIN_PASSWORD"
  [[ -z "${COMPASS_ADMIN_NAME:-}" ]] && missing="$missing COMPASS_ADMIN_NAME"
  [[ -z "${COMPASS_ADMIN_ORG:-}" ]] && missing="$missing COMPASS_ADMIN_ORG"
  if [[ -n "$missing" ]]; then
    echo "ERROR: Silent mode requires these environment variables:${missing}"
    exit 1
  fi
fi

# ---------------------------------------------------------------------------
# Banner
# ---------------------------------------------------------------------------
echo -e "${BOLD}DATA Compass Installer${NC} v${VERSION}"
echo "Install directory: ${INSTALL_DIR}"
echo "Offline mode:      ${OFFLINE}"
[[ "$COMPASS_SILENT" == true ]] && echo "Silent mode:       yes"
[[ "$COMPASS_DRY_RUN" == true ]] && echo "Dry-run mode:      yes"
echo ""

# ---------------------------------------------------------------------------
# Dry-run mode: show plan and exit
# ---------------------------------------------------------------------------
if [[ "$COMPASS_DRY_RUN" == true ]]; then
  echo -e "${BOLD}Dry-run: Installation plan${NC}"
  echo ""
  echo "  Step 1: Prerequisites check (Docker, Compose, resources, ports, tools)"
  echo "  Step 2: Create directories in ${INSTALL_DIR}"
  echo "  Step 3: Generate configuration (secrets, .env)"
  echo "  Step 4: Load Docker images (offline=${OFFLINE})"
  echo "  Step 5: Initialize PostgreSQL database"
  echo "  Step 6: Create admin user"
  echo "  Step 7: Start all services"
  echo "  Step 8: Health check + smoke tests"
  echo ""

  # Still run preflight in dry-run to show real status
  echo -e "${BOLD}Preflight results:${NC}"
  preflight_run_all "$INSTALL_DIR" "$COMPASS_PORT" || true
  echo ""
  echo -e "${YELLOW}Dry-run complete. No changes were made.${NC}"
  exit 0
fi

# ---------------------------------------------------------------------------
# Initialize logging and rollback
# ---------------------------------------------------------------------------
logging_init "$INSTALL_DIR"
rollback_enable "$INSTALL_DIR"
common_set_total_steps 8

# Ensure spinner is cleaned up on exit (rollback_clear is called by rollback_mark_success on success)
trap 'stop_spinner' EXIT

# ==========================================================================
# Step 1: Prerequisites Check
# ==========================================================================
step "Prerequisites Check"

# If Docker is missing, try auto-install
if ! preflight_check_docker; then
  if [[ "$COMPASS_SILENT" == true ]]; then
    if [[ "${COMPASS_INSTALL_DOCKER:-}" == "yes" ]]; then
      docker_install_run true
    else
      fail "Docker not found. Set COMPASS_INSTALL_DOCKER=yes for auto-install."
      exit 1
    fi
  else
    docker_install_run false
  fi

  # Re-check after install attempt
  if ! preflight_check_docker; then
    fail "Docker Engine not found after install attempt."
    exit 1
  fi
fi

preflight_check_compose || exit 1
preflight_check_tools || true  # warn but don't fail for tools
preflight_check_resources "$INSTALL_DIR" || true  # warn but continue for resources
preflight_check_ports "$COMPASS_PORT" || true
preflight_check_selinux

# ==========================================================================
# Step 2: Directory Structure
# ==========================================================================
step "Directory Structure"

FRESH_INSTALL=false
if [[ ! -d "${INSTALL_DIR}/data" ]]; then
  FRESH_INSTALL=true
fi

mkdir -p "${INSTALL_DIR}/data/uploads"
mkdir -p "${INSTALL_DIR}/data/exports"
mkdir -p "${INSTALL_DIR}/data/backups"
mkdir -p "${INSTALL_DIR}/logs"

ok "Created ${INSTALL_DIR}/data/{uploads,exports,backups}"
ok "Created ${INSTALL_DIR}/logs"

# Copy compose files and deploy scripts
cp -f "$PROJECT_ROOT/docker-compose.yml"      "${INSTALL_DIR}/"
cp -f "$PROJECT_ROOT/docker-compose.prod.yml"  "${INSTALL_DIR}/"
cp -f "$PROJECT_ROOT/compass-config.yaml.template" "${INSTALL_DIR}/"
cp -rf "$PROJECT_ROOT/deploy/"                 "${INSTALL_DIR}/deploy/"

ok "Copied Docker Compose and deployment files"

# Rollback: remove directories only if this was a fresh install
if [[ "$FRESH_INSTALL" == true ]]; then
  rollback_push "rm -rf '${INSTALL_DIR}/data' '${INSTALL_DIR}/logs'" "Remove created directories"
fi

# ==========================================================================
# Step 3: Generate Configuration
# ==========================================================================
step "Generate Configuration"

# License file prompt FIRST (matches Quick Start doc order: License → API key → Proxy)
_license_src="${LICENSE_FILE:-${COMPASS_LICENSE_FILE:-}}"
if [[ -z "$_license_src" && "$COMPASS_SILENT" != true ]]; then
  echo -n "Path to license key file (or press Enter to skip for evaluation): "
  read -r _license_src
fi

# Generate config (prompts for API key + proxy in interactive mode)
config_gen_full "$INSTALL_DIR" "$CONFIG_FILE" "$COMPASS_SILENT"

# Install license file after config generation
if [[ -n "$_license_src" ]]; then
  if [[ ! -f "$_license_src" ]]; then
    fail "License file not found: $_license_src"
    exit 1
  fi
  cp "$_license_src" "${INSTALL_DIR}/compass-license.key"
  chmod 644 "${INSTALL_DIR}/compass-license.key"
  ok "License file installed: ${INSTALL_DIR}/compass-license.key"
  # Enable license enforcement now that a valid file is present
  sed -i "s/^COMPASS_LICENSE_REQUIRED=.*/COMPASS_LICENSE_REQUIRED=true/" "${INSTALL_DIR}/.env"
  ok "License enforcement enabled in .env"
else
  warn "No license file provided. A license is required for production use."
  info "App will start without license enforcement (COMPASS_LICENSE_REQUIRED=false)."
  # Create an empty placeholder so the Docker bind mount doesn't create a directory
  touch "${INSTALL_DIR}/compass-license.key"
  chmod 644 "${INSTALL_DIR}/compass-license.key"
fi

rollback_push "rm -f '${INSTALL_DIR}/compass-config.yaml' '${INSTALL_DIR}/.env'" "Remove generated config"

# ==========================================================================
# Step 4: Load Docker Images
# ==========================================================================
step "Load Docker Images"

cd "${INSTALL_DIR}"

# Look for pre-built images in install dir first, then in the source package dir
IMAGES_TAR=""
for _dir in "${INSTALL_DIR}" "${PROJECT_ROOT}"; do
  if [[ -f "${_dir}/compass-images.tar.gz" ]]; then
    IMAGES_TAR="${_dir}/compass-images.tar.gz"
    break
  fi
done

if [[ -n "$IMAGES_TAR" ]]; then
  start_spinner "Loading Docker images from package..."
  docker load < "$IMAGES_TAR"
  stop_spinner
  ok "Docker images loaded from ${IMAGES_TAR}"
elif [[ "$OFFLINE" == true ]]; then
  fail "Offline mode: compass-images.tar.gz not found."
  exit 1
else
  start_spinner "Pulling Docker images from registry..."
  docker compose pull
  stop_spinner
  ok "Docker images pulled from registry"
fi

# ==========================================================================
# Step 5: Initialize Database
# ==========================================================================
step "Initialize Database"

start_spinner "Starting PostgreSQL..."
docker compose up -d postgres
stop_spinner

# Wait for PostgreSQL to be healthy
RETRIES=30
start_spinner "Waiting for PostgreSQL to be ready..."
until docker compose exec postgres pg_isready -U compassadmin -d compass_dev &>/dev/null; do
  RETRIES=$((RETRIES - 1))
  if [[ $RETRIES -le 0 ]]; then
    stop_spinner
    fail "PostgreSQL did not become ready within 60 seconds."
    exit 1
  fi
  sleep 2
done
stop_spinner

ok "PostgreSQL is ready"
info "Migrations will run automatically on first app startup (RUN_MIGRATIONS=true)"

rollback_push "cd '${INSTALL_DIR}' && docker compose down postgres 2>/dev/null || true" "Stop PostgreSQL"

# ==========================================================================
# Step 6: Create Initial Admin User
# ==========================================================================
step "Create Initial Admin User"

if [[ "$COMPASS_SILENT" == true ]]; then
  ADMIN_EMAIL="${COMPASS_ADMIN_EMAIL}"
  ADMIN_NAME="${COMPASS_ADMIN_NAME}"
  ADMIN_ORG="${COMPASS_ADMIN_ORG}"
  ADMIN_PASSWORD="${COMPASS_ADMIN_PASSWORD}"
else
  echo -n "Admin email: "
  read -r ADMIN_EMAIL

  echo -n "Admin full name: "
  read -r ADMIN_NAME

  echo -n "Organization name: "
  read -r ADMIN_ORG

  echo -n "Admin password (min 8 chars): "
  read -rs ADMIN_PASSWORD
  echo ""
fi

# Start app temporarily for admin creation
start_spinner "Starting application for admin setup..."
docker compose -f docker-compose.yml -f docker-compose.prod.yml up -d --no-build app
stop_spinner

# Wait for app to be ready
# First boot runs 93+ database migrations — allow up to 5 minutes
APP_RETRIES=150
start_spinner "Waiting for application to be ready (first boot runs migrations, this may take a few minutes)..."
until curl -sf http://localhost:${COMPASS_PORT}/health &>/dev/null; do
  APP_RETRIES=$((APP_RETRIES - 1))
  if [[ $APP_RETRIES -le 0 ]]; then
    stop_spinner
    warn "App not ready after 5 minutes. Admin user will need to be created manually."
    info "Run: ./deploy/create-admin.sh --org \"${ADMIN_ORG}\" --email \"${ADMIN_EMAIL}\" --name \"${ADMIN_NAME}\""
    break
  fi
  sleep 2
done
stop_spinner

if [[ $APP_RETRIES -gt 0 ]]; then
  # Pass all values as env vars to avoid shell injection (e.g., org names with quotes)
  docker compose exec \
    -e ADMIN_PASSWORD="$ADMIN_PASSWORD" \
    -e ADMIN_ORG="$ADMIN_ORG" \
    -e ADMIN_EMAIL="$ADMIN_EMAIL" \
    -e ADMIN_NAME="$ADMIN_NAME" \
    app sh -c 'node dist/db/seedPocUsers.js --org "$ADMIN_ORG" --email "$ADMIN_EMAIL" --password "$ADMIN_PASSWORD" --name "$ADMIN_NAME"' \
    && ok "Admin user created" \
    || warn "Admin creation failed. You can retry manually after installation."
fi

rollback_push "cd '${INSTALL_DIR}' && docker compose down 2>/dev/null || true" "Stop all services"

# ==========================================================================
# Step 7: Start Services
# ==========================================================================
step "Start Services"

start_spinner "Starting all services..."
docker compose -f docker-compose.yml -f docker-compose.prod.yml up -d --no-build
stop_spinner

ok "All services started"

# ==========================================================================
# Step 8: Health Check
# ==========================================================================
step "Health Check"

HEALTH_RETRIES=60
HEALTH_URL="http://localhost:${COMPASS_PORT}/health/ready"

start_spinner "Waiting for application to become ready..."
until curl -sf "$HEALTH_URL" &>/dev/null; do
  HEALTH_RETRIES=$((HEALTH_RETRIES - 1))
  if [[ $HEALTH_RETRIES -le 0 ]]; then
    stop_spinner
    warn "Application did not respond within 120 seconds."
    echo ""
    echo -e "${YELLOW}Troubleshooting:${NC}"
    echo "  1. Check logs:    docker compose logs -f app"
    echo "  2. Check health:  curl http://localhost:${COMPASS_PORT}/health"
    echo "  3. Check DB:      docker compose exec postgres pg_isready -U compassadmin"
    echo "  4. Restart:       docker compose -f docker-compose.yml -f docker-compose.prod.yml restart app"
    logging_finish 1
    exit 1
  fi
  sleep 2
done
stop_spinner

# Mark success — disables rollback, creates marker
rollback_mark_success "$INSTALL_DIR"
logging_finish 0

echo ""
echo -e "${GREEN}${BOLD}=====================================${NC}"
echo -e "${GREEN}${BOLD}  DATA Compass is ready!${NC}"
echo -e "${GREEN}${BOLD}=====================================${NC}"
echo ""
echo -e "  Access URL:     ${BOLD}http://$(hostname -f 2>/dev/null || echo 'localhost'):${COMPASS_PORT}${NC}"
echo -e "  Admin email:    ${BOLD}${ADMIN_EMAIL:-<configured>}${NC}"
echo -e "  Config file:    ${INSTALL_DIR}/compass-config.yaml"
echo -e "  Install log:    ${INSTALL_DIR}/logs/install.log"
echo -e "  Logs:           docker compose logs -f app"
echo -e "  Stop:           docker compose down"
echo ""
echo -e "  ${YELLOW}Next steps:${NC}"
echo "    1. Configure TLS (see deploy/NETWORK_REQUIREMENTS.md)"
echo "    2. Set up backups (see deploy/backup.sh)"
echo "    3. Review deploy/CONSULTANT_RUNBOOK.md"
