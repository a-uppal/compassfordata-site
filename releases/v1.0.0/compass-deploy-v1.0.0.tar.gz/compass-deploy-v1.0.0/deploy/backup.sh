#!/usr/bin/env bash
# =============================================================================
# DATA Compass - Automated PostgreSQL Backup (DC-1302)
#
# Creates compressed PostgreSQL backups with configurable retention.
# Designed for cron-based scheduling in customer deployments.
#
# Usage:
#   ./backup.sh                     # Backup with 7-day retention (default)
#   ./backup.sh --retain 30         # Backup with 30-day retention
#   ./backup.sh --restore <file>    # Restore from a backup file
#   ./backup.sh --list              # List available backups
#
# Environment:
#   BACKUP_DIR          Backup directory (default: /opt/compass/data/backups)
#   RETAIN_DAYS         Retention period in days (default: 7, overridden by --retain)
#   POSTGRES_CONTAINER  Docker container name (default: faircompass-postgres)
#   PGUSER              PostgreSQL user (default: compassadmin)
#   PGDATABASE          PostgreSQL database (default: compass_dev, matches docker-compose.yml)
#
# Cron example (daily at 2am):
#   0 2 * * * /opt/compass/deploy/backup.sh >> /opt/compass/logs/backup.log 2>&1
# =============================================================================

set -euo pipefail

# =============================================================================
# CONFIGURATION
# =============================================================================

BACKUP_DIR="${BACKUP_DIR:-/opt/compass/data/backups}"
RETAIN_DAYS="${RETAIN_DAYS:-7}"
POSTGRES_CONTAINER="${POSTGRES_CONTAINER:-faircompass-postgres}"
PGUSER="${PGUSER:-compassadmin}"
PGDATABASE="${PGDATABASE:-compass_dev}"

# Color output (disabled if not a terminal or NO_COLOR is set)
if [[ -n "${NO_COLOR:-}" ]] || [ ! -t 1 ]; then
  RED=''; GREEN=''; YELLOW=''; BLUE=''; NC=''
else
  RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[0;34m'; NC='\033[0m'
fi

log()  { echo -e "${BLUE}[backup]${NC} $(date '+%Y-%m-%d %H:%M:%S') $*"; }
warn() { echo -e "${YELLOW}[backup]${NC} $(date '+%Y-%m-%d %H:%M:%S') WARNING: $*"; }
err()  { echo -e "${RED}[backup]${NC} $(date '+%Y-%m-%d %H:%M:%S') ERROR: $*" >&2; }
ok()   { echo -e "${GREEN}[backup]${NC} $(date '+%Y-%m-%d %H:%M:%S') $*"; }

# =============================================================================
# PARSE ARGUMENTS
# =============================================================================

MODE="backup"
RESTORE_FILE=""

while [[ $# -gt 0 ]]; do
  case "$1" in
    --retain)
      RETAIN_DAYS="$2"
      shift 2
      ;;
    --restore)
      MODE="restore"
      RESTORE_FILE="$2"
      shift 2
      ;;
    --list)
      MODE="list"
      shift
      ;;
    --help|-h)
      echo "Usage: $0 [--retain DAYS] [--restore FILE] [--list] [--help]"
      echo ""
      echo "Options:"
      echo "  --retain DAYS    Set retention period (default: 7)"
      echo "  --restore FILE   Restore from backup file"
      echo "  --list           List available backups"
      echo "  --help           Show this help"
      exit 0
      ;;
    *)
      err "Unknown argument: $1"
      exit 1
      ;;
  esac
done

# =============================================================================
# PREREQUISITES
# =============================================================================

check_docker() {
  if ! command -v docker &>/dev/null; then
    err "Docker is not installed or not in PATH"
    exit 1
  fi

  if ! docker ps &>/dev/null; then
    err "Docker is not running or current user lacks permissions"
    exit 1
  fi

  if ! docker ps --format '{{.Names}}' | grep -q "^${POSTGRES_CONTAINER}$"; then
    err "PostgreSQL container '${POSTGRES_CONTAINER}' is not running"
    err "Start it with: docker compose up -d postgres"
    exit 1
  fi
}

ensure_backup_dir() {
  if [ ! -d "$BACKUP_DIR" ]; then
    log "Creating backup directory: $BACKUP_DIR"
    mkdir -p "$BACKUP_DIR"
  fi
}

# =============================================================================
# BACKUP
# =============================================================================

do_backup() {
  check_docker
  ensure_backup_dir

  local TIMESTAMP
  TIMESTAMP=$(date +%Y%m%d_%H%M%S)
  local BACKUP_FILE="${BACKUP_DIR}/compass_${TIMESTAMP}.dump"

  log "Starting PostgreSQL backup..."
  log "  Container: ${POSTGRES_CONTAINER}"
  log "  Database:  ${PGDATABASE}"
  log "  Output:    ${BACKUP_FILE}"

  # Run pg_dump inside the container, stream to host file
  if docker exec "${POSTGRES_CONTAINER}" \
    pg_dump -U "${PGUSER}" -Fc "${PGDATABASE}" \
    > "${BACKUP_FILE}"; then

    local SIZE
    SIZE=$(du -h "${BACKUP_FILE}" | cut -f1)
    ok "Backup complete: ${BACKUP_FILE} (${SIZE})"

    # Generate checksum
    sha256sum "${BACKUP_FILE}" > "${BACKUP_FILE}.sha256" 2>/dev/null || true
  else
    err "Backup failed!"
    rm -f "${BACKUP_FILE}"
    exit 1
  fi

  # Prune old backups
  prune_backups
}

# =============================================================================
# PRUNE
# =============================================================================

prune_backups() {
  log "Pruning backups older than ${RETAIN_DAYS} days..."

  local COUNT
  COUNT=$(find "${BACKUP_DIR}" -name "compass_*.dump" -mtime "+${RETAIN_DAYS}" 2>/dev/null | wc -l)

  if [ "$COUNT" -gt 0 ]; then
    find "${BACKUP_DIR}" -name "compass_*.dump" -mtime "+${RETAIN_DAYS}" -delete
    find "${BACKUP_DIR}" -name "compass_*.dump.sha256" -mtime "+${RETAIN_DAYS}" -delete 2>/dev/null || true
    log "Removed ${COUNT} old backup(s)"
  else
    log "No old backups to remove"
  fi
}

# =============================================================================
# RESTORE
# =============================================================================

do_restore() {
  check_docker

  if [ ! -f "$RESTORE_FILE" ]; then
    err "Backup file not found: $RESTORE_FILE"
    exit 1
  fi

  # Verify checksum if available
  if [ -f "${RESTORE_FILE}.sha256" ]; then
    log "Verifying checksum..."
    if sha256sum -c "${RESTORE_FILE}.sha256" &>/dev/null; then
      ok "Checksum verified"
    else
      warn "Checksum verification failed! File may be corrupted."
      echo -n "Continue anyway? [y/N] "
      read -r REPLY
      if [[ ! "$REPLY" =~ ^[Yy]$ ]]; then
        exit 1
      fi
    fi
  fi

  log "Restoring from: ${RESTORE_FILE}"
  warn "This will REPLACE the current database contents!"
  echo -n "Proceed? [y/N] "
  read -r REPLY
  if [[ ! "$REPLY" =~ ^[Yy]$ ]]; then
    log "Restore cancelled"
    exit 0
  fi

  if docker exec -i "${POSTGRES_CONTAINER}" \
    pg_restore -U "${PGUSER}" -d "${PGDATABASE}" --clean --if-exists \
    < "${RESTORE_FILE}"; then
    ok "Restore complete from: ${RESTORE_FILE}"
  else
    # pg_restore returns non-zero on warnings too, which is normal
    warn "Restore completed with warnings (this is often normal for pg_restore)"
  fi
}

# =============================================================================
# LIST
# =============================================================================

do_list() {
  ensure_backup_dir

  local COUNT
  COUNT=$(find "${BACKUP_DIR}" -name "compass_*.dump" 2>/dev/null | wc -l)

  if [ "$COUNT" -eq 0 ]; then
    log "No backups found in ${BACKUP_DIR}"
    return
  fi

  log "Available backups in ${BACKUP_DIR}:"
  echo ""
  printf "  %-40s  %s\n" "FILENAME" "SIZE"
  printf "  %-40s  %s\n" "--------" "----"

  find "${BACKUP_DIR}" -name "compass_*.dump" -printf "  %-40f  %s\n" 2>/dev/null | \
    sort -r | head -20 || \
    ls -lhS "${BACKUP_DIR}"/compass_*.dump 2>/dev/null | awk '{printf "  %-40s  %s\n", $NF, $5}'

  echo ""
  log "Total: ${COUNT} backup(s)"
  log "Retention: ${RETAIN_DAYS} days"
}

# =============================================================================
# MAIN
# =============================================================================

case "$MODE" in
  backup)  do_backup ;;
  restore) do_restore ;;
  list)    do_list ;;
esac
