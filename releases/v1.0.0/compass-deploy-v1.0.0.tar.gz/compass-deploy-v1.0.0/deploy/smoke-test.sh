#!/usr/bin/env bash
# =============================================================================
# DATA Compass - Smoke Test Script
# =============================================================================
# Tests critical endpoints after deployment to verify the application is
# functioning correctly. Use after install, upgrade, or rollback.
#
# Usage:
#   ./deploy/smoke-test.sh                         # Default: http://localhost:3001
#   ./deploy/smoke-test.sh --url http://host:3001  # Custom base URL
#   ./deploy/smoke-test.sh --url https://compass.example.com
#
# Exit codes:
#   0 - All tests passed
#   1 - One or more tests failed
# =============================================================================

set -euo pipefail

# ---------------------------------------------------------------------------
# Colors & helpers
# ---------------------------------------------------------------------------
if [[ -n "${NO_COLOR:-}" ]] || [ ! -t 1 ]; then
  RED=''; GREEN=''; YELLOW=''; BLUE=''; BOLD=''; NC=''
else
  RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
  BLUE='\033[0;34m'; BOLD='\033[1m'; NC='\033[0m'
fi

ok()   { echo -e "  ${GREEN}[PASS]${NC} $1"; }
fail() { echo -e "  ${RED}[FAIL]${NC} $1"; FAILURES=$((FAILURES + 1)); }
skip() { echo -e "  ${YELLOW}[SKIP]${NC} $1"; }

# ---------------------------------------------------------------------------
# Arguments
# ---------------------------------------------------------------------------
BASE_URL="${COMPASS_URL:-http://localhost:3001}"
TIMEOUT=10

while [[ $# -gt 0 ]]; do
  case "$1" in
    --url) BASE_URL="$2"; shift 2 ;;
    --timeout) TIMEOUT="$2"; shift 2 ;;
    -h|--help)
      echo "Usage: $0 [--url BASE_URL] [--timeout SECONDS]"
      echo ""
      echo "Options:"
      echo "  --url URL      Base URL (default: http://localhost:3001)"
      echo "  --timeout SEC  Request timeout in seconds (default: 10)"
      exit 0
      ;;
    *) echo -e "${RED}Unknown option: $1${NC}"; exit 1 ;;
  esac
done

FAILURES=0

echo ""
echo -e "${BOLD}DATA Compass Smoke Test${NC}"
echo -e "Target: ${BLUE}${BASE_URL}${NC}"
echo ""

# ---------------------------------------------------------------------------
# Test 1: Liveness
# ---------------------------------------------------------------------------
echo -e "${BOLD}Endpoint Tests:${NC}"

HTTP_CODE=$(curl -sf -o /dev/null -w "%{http_code}" --max-time "$TIMEOUT" "${BASE_URL}/health/live" 2>/dev/null || echo "000")
if [ "$HTTP_CODE" = "200" ]; then
  ok "GET /health/live -> HTTP $HTTP_CODE"
else
  fail "GET /health/live -> HTTP $HTTP_CODE (expected 200)"
fi

# ---------------------------------------------------------------------------
# Test 2: Readiness
# ---------------------------------------------------------------------------
HTTP_CODE=$(curl -sf -o /dev/null -w "%{http_code}" --max-time "$TIMEOUT" "${BASE_URL}/health/ready" 2>/dev/null || echo "000")
if [ "$HTTP_CODE" = "200" ]; then
  ok "GET /health/ready -> HTTP $HTTP_CODE"
else
  fail "GET /health/ready -> HTTP $HTTP_CODE (expected 200)"
fi

# ---------------------------------------------------------------------------
# Test 3: Full health (with response body check)
# ---------------------------------------------------------------------------
HEALTH_BODY=$(curl -sf --max-time "$TIMEOUT" "${BASE_URL}/health" 2>/dev/null || echo "")
if echo "$HEALTH_BODY" | grep -q '"ok":true'; then
  ok "GET /health -> ok:true"
else
  fail "GET /health -> response did not contain ok:true"
fi

# ---------------------------------------------------------------------------
# Test 4: Migration status
# ---------------------------------------------------------------------------
MIGRATION_BODY=$(curl -sf --max-time "$TIMEOUT" "${BASE_URL}/health/migrations" 2>/dev/null || echo "")
if echo "$MIGRATION_BODY" | grep -q '"pending"'; then
  PENDING=$(echo "$MIGRATION_BODY" | grep -o '"pending":[0-9]*' | cut -d: -f2)
  if [ "${PENDING:-1}" = "0" ]; then
    ok "GET /health/migrations -> 0 pending"
  else
    fail "GET /health/migrations -> ${PENDING} pending migrations"
  fi
else
  skip "GET /health/migrations -> endpoint not available"
fi

# ---------------------------------------------------------------------------
# Test 5: SPA root (should serve HTML)
# ---------------------------------------------------------------------------
SPA_CODE=$(curl -sf -o /dev/null -w "%{http_code}" --max-time "$TIMEOUT" "${BASE_URL}/" 2>/dev/null || echo "000")
if [ "$SPA_CODE" = "200" ]; then
  ok "GET / -> HTTP $SPA_CODE (SPA serving)"
else
  fail "GET / -> HTTP $SPA_CODE (expected 200 for SPA)"
fi

# ---------------------------------------------------------------------------
# Test 6: Login page (SPA route, should return 200)
# ---------------------------------------------------------------------------
LOGIN_CODE=$(curl -sf -o /dev/null -w "%{http_code}" --max-time "$TIMEOUT" "${BASE_URL}/login" 2>/dev/null || echo "000")
if [ "$LOGIN_CODE" = "200" ]; then
  ok "GET /login -> HTTP $LOGIN_CODE (SPA route)"
else
  fail "GET /login -> HTTP $LOGIN_CODE (expected 200)"
fi

# ---------------------------------------------------------------------------
# Test 7: API endpoint (expects 401 without auth)
# ---------------------------------------------------------------------------
API_CODE=$(curl -s -o /dev/null -w "%{http_code}" --max-time "$TIMEOUT" "${BASE_URL}/api/journey" 2>/dev/null)
if [ "$API_CODE" = "401" ] || [ "$API_CODE" = "200" ]; then
  ok "GET /api/journey -> HTTP $API_CODE (API responding)"
else
  fail "GET /api/journey -> HTTP $API_CODE (expected 401 or 200)"
fi

# ---------------------------------------------------------------------------
# Summary
# ---------------------------------------------------------------------------
echo ""
if [ "$FAILURES" -eq 0 ]; then
  echo -e "${GREEN}${BOLD}All smoke tests passed.${NC}"
  exit 0
else
  echo -e "${RED}${BOLD}${FAILURES} test(s) failed.${NC}"
  exit 1
fi
