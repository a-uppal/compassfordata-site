#!/usr/bin/env bash
# =============================================================================
# deploy/lib/preflight.sh — Prerequisite checks (DC-1445, DC-1447)
# =============================================================================
# Source this file after common.sh. Defines preflight_* functions.
# =============================================================================

[[ -n "${_COMPASS_PREFLIGHT_LOADED:-}" ]] && return 0
_COMPASS_PREFLIGHT_LOADED=1

# ---------------------------------------------------------------------------
# Docker Engine check
# ---------------------------------------------------------------------------
preflight_check_docker() {
  if command -v docker &>/dev/null; then
    local docker_version
    docker_version=$(docker version --format '{{.Server.Version}}' 2>/dev/null || echo "unknown")
    ok "Docker Engine: v${docker_version}"
    return 0
  else
    return 1
  fi
}

# ---------------------------------------------------------------------------
# Docker Compose v2 check
# ---------------------------------------------------------------------------
preflight_check_compose() {
  if docker compose version &>/dev/null; then
    local compose_version
    compose_version=$(docker compose version --short 2>/dev/null || echo "unknown")
    ok "Docker Compose: v${compose_version}"
    return 0
  else
    fail "Docker Compose v2 not found. Install Docker Compose v2+."
    return 1
  fi
}

# ---------------------------------------------------------------------------
# System resources (RAM, CPU, disk)
# ---------------------------------------------------------------------------
preflight_check_resources() {
  local install_dir="${1:-/opt/compass}"
  local errors=0

  # Memory
  local total_mem_kb total_mem_gb
  total_mem_kb=$(grep MemTotal /proc/meminfo 2>/dev/null | awk '{print $2}' || echo "0")
  total_mem_gb=$((total_mem_kb / 1024 / 1024))

  if [[ $total_mem_gb -ge 8 ]]; then
    ok "Memory: ${total_mem_gb}GB (minimum 8GB)"
  elif [[ $total_mem_gb -ge 4 ]]; then
    warn "Memory: ${total_mem_gb}GB (8GB recommended, 4GB minimum)"
  else
    fail "Insufficient memory: ${total_mem_gb}GB. Minimum 4GB, recommended 8GB."
    errors=$((errors + 1))
  fi

  # CPUs
  local cpu_count
  cpu_count=$(nproc 2>/dev/null || sysctl -n hw.ncpu 2>/dev/null || echo "0")

  if [[ $cpu_count -ge 4 ]]; then
    ok "CPUs: ${cpu_count} (minimum 4)"
  elif [[ $cpu_count -ge 2 ]]; then
    warn "CPUs: ${cpu_count} (4 recommended, 2 minimum)"
  else
    fail "Insufficient CPUs: ${cpu_count}. Minimum 2, recommended 4."
    errors=$((errors + 1))
  fi

  # Disk space
  local avail_disk_kb avail_disk_gb
  avail_disk_kb=$(df "${install_dir%/*}" 2>/dev/null | tail -1 | awk '{print $4}' || echo "0")
  avail_disk_gb=$((avail_disk_kb / 1024 / 1024))

  if [[ $avail_disk_gb -ge 50 ]]; then
    ok "Disk space: ${avail_disk_gb}GB available (minimum 50GB)"
  elif [[ $avail_disk_gb -ge 20 ]]; then
    warn "Disk space: ${avail_disk_gb}GB available (50GB recommended)"
  else
    fail "Insufficient disk space: ${avail_disk_gb}GB. Minimum 20GB, recommended 50GB."
    errors=$((errors + 1))
  fi

  return $errors
}

# ---------------------------------------------------------------------------
# Port availability check (DC-1447)
# ---------------------------------------------------------------------------
preflight_check_port() {
  local port="$1"
  local description="${2:-port $port}"

  # Try ss first, then /dev/tcp probe
  if command -v ss &>/dev/null; then
    if ss -tlnp 2>/dev/null | grep -q ":${port} "; then
      fail "Port ${port} (${description}) is already in use"
      return 1
    fi
  elif (echo >/dev/tcp/localhost/"$port") 2>/dev/null; then
    fail "Port ${port} (${description}) is already in use"
    return 1
  fi

  ok "Port ${port} (${description}) is available"
  return 0
}

preflight_check_ports() {
  local compass_port="${1:-3001}"
  local pg_port="${2:-5432}"
  local errors=0

  preflight_check_port "$compass_port" "Compass HTTP" || errors=$((errors + 1))
  preflight_check_port "$pg_port" "PostgreSQL" || errors=$((errors + 1))

  return $errors
}

# ---------------------------------------------------------------------------
# Required tools check (DC-1447)
# ---------------------------------------------------------------------------
preflight_check_tools() {
  local errors=0

  for tool in openssl curl sha256sum; do
    if command -v "$tool" &>/dev/null; then
      ok "Tool available: ${tool}"
    else
      fail "Required tool not found: ${tool}"
      errors=$((errors + 1))
    fi
  done

  # Bash version >= 4.0
  local bash_major="${BASH_VERSINFO[0]:-0}"
  if [[ $bash_major -ge 4 ]]; then
    ok "Bash version: ${BASH_VERSION} (>= 4.0)"
  else
    fail "Bash version ${BASH_VERSION} is too old. Require >= 4.0."
    errors=$((errors + 1))
  fi

  return $errors
}

# ---------------------------------------------------------------------------
# SELinux check (DC-1447) — relevant on RHEL/CentOS/Fedora
# ---------------------------------------------------------------------------
preflight_check_selinux() {
  if command -v getenforce &>/dev/null; then
    local mode
    mode=$(getenforce 2>/dev/null || echo "Unknown")
    if [[ "$mode" == "Enforcing" ]]; then
      warn "SELinux is in Enforcing mode. Docker volumes may require ':z' or ':Z' labels."
      warn "Consider: setsebool -P container_manage_cgroup on"
      return 0
    elif [[ "$mode" == "Permissive" ]]; then
      info "SELinux: Permissive mode"
    else
      info "SELinux: ${mode}"
    fi
  fi
  return 0
}

# ---------------------------------------------------------------------------
# Run all preflight checks
# ---------------------------------------------------------------------------
preflight_run_all() {
  local install_dir="${1:-/opt/compass}"
  local compass_port="${2:-3001}"
  local errors=0

  preflight_check_tools || errors=$((errors + $?))
  preflight_check_docker || errors=$((errors + 1))
  preflight_check_compose || errors=$((errors + 1))
  preflight_check_resources "$install_dir" || errors=$((errors + $?))
  preflight_check_ports "$compass_port" || errors=$((errors + $?))
  preflight_check_selinux

  return $errors
}
