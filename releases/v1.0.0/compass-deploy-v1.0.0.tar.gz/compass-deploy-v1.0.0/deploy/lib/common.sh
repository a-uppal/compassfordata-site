#!/usr/bin/env bash
# =============================================================================
# deploy/lib/common.sh — Shared colors, output helpers, spinner (DC-1445)
# =============================================================================
# Source this file; it defines functions with no side effects.
# All functions prefixed with common_ except ok/warn/fail/info/step_header.
#
# Usage:
#   LIB_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
#   . "$LIB_DIR/common.sh"
# =============================================================================

# Guard against double-sourcing
[[ -n "${_COMPASS_COMMON_LOADED:-}" ]] && return 0
_COMPASS_COMMON_LOADED=1

# ---------------------------------------------------------------------------
# Colors (respects NO_COLOR, non-interactive, and silent mode)
# ---------------------------------------------------------------------------
common_init_colors() {
  if [[ -n "${NO_COLOR:-}" ]] || [[ -n "${COMPASS_SILENT:-}" ]] || [ ! -t 1 ]; then
    RED=''; GREEN=''; YELLOW=''; BLUE=''; CYAN=''; BOLD=''; DIM=''; NC=''
  else
    RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
    BLUE='\033[0;34m'; CYAN='\033[0;36m'; BOLD='\033[1m'; DIM='\033[2m'; NC='\033[0m'
  fi
}

# Initialize on source (caller can re-invoke if COMPASS_SILENT changes)
common_init_colors

# ---------------------------------------------------------------------------
# Output helpers — dual-write to terminal and log (if logging loaded)
# ---------------------------------------------------------------------------
ok()   {
  echo -e "  ${GREEN}[OK]${NC} $1"
  [[ "$(type -t logging_write 2>/dev/null)" == "function" ]] && logging_write "INFO" "$1" || true
}

warn() {
  echo -e "  ${YELLOW}[WARN]${NC} $1"
  [[ "$(type -t logging_write 2>/dev/null)" == "function" ]] && logging_write "WARN" "$1" || true
}

fail() {
  echo -e "  ${RED}[FAIL]${NC} $1"
  [[ "$(type -t logging_write 2>/dev/null)" == "function" ]] && logging_write "ERROR" "$1" || true
}

info() {
  echo -e "  ${CYAN}[INFO]${NC} $1"
  [[ "$(type -t logging_write 2>/dev/null)" == "function" ]] && logging_write "INFO" "$1" || true
}

# ---------------------------------------------------------------------------
# Step header with box drawing
# ---------------------------------------------------------------------------
common_step_num=0
common_total_steps=8

common_set_total_steps() {
  common_total_steps="${1:-8}"
}

step() {
  common_step_num=$((common_step_num + 1))
  echo ""
  echo -e "${BLUE}${BOLD}=== Step ${common_step_num}/${common_total_steps}: $1 ===${NC}"
  [[ "$(type -t logging_write 2>/dev/null)" == "function" ]] && logging_write "INFO" "step=${common_step_num}/${common_total_steps} action=\"$1\"" || true
}

step_header() {
  local title="$1"
  local width=${#title}
  local pad=$((width + 4))

  echo ""
  if locale charmap 2>/dev/null | grep -qi utf; then
    printf "  ${BOLD}${BLUE}"
    printf '\u250C'; printf '\u2500%.0s' $(seq 1 $pad); printf '\u2510\n'
    printf '  \u2502  %s  \u2502\n' "$title"
    printf '  \u2514'; printf '\u2500%.0s' $(seq 1 $pad); printf '\u2518'
    printf "${NC}\n"
  else
    printf "  ${BOLD}${BLUE}"
    printf '+'; printf -- '-%.0s' $(seq 1 $pad); printf '+\n'
    printf '  |  %s  |\n' "$title"
    printf '  +'; printf -- '-%.0s' $(seq 1 $pad); printf '+'
    printf "${NC}\n"
  fi
  echo ""
}

# ---------------------------------------------------------------------------
# Spinner for long-running operations
# ---------------------------------------------------------------------------
_spinner_pid=""

start_spinner() {
  local msg="${1:-Working...}"
  # Skip spinner in silent mode or non-interactive
  if [[ -n "${COMPASS_SILENT:-}" ]] || [ ! -t 1 ]; then
    return 0
  fi
  (
    local chars='|/-\'
    local i=0
    while true; do
      printf "\r  %s %s " "${chars:i%4:1}" "$msg"
      i=$((i + 1))
      sleep 0.15
    done
  ) &
  _spinner_pid=$!
  disown "$_spinner_pid" 2>/dev/null || true
}

stop_spinner() {
  if [[ -n "$_spinner_pid" ]]; then
    kill "$_spinner_pid" 2>/dev/null || true
    wait "$_spinner_pid" 2>/dev/null || true
    _spinner_pid=""
    printf "\r\033[K"
  fi
}

# ---------------------------------------------------------------------------
# Sanitize a string for safe use in sed replacement patterns
# Escapes: \ / & newline (the special chars in sed s|old|new| replacements)
# Also escapes | since we use | as the sed delimiter.
# ---------------------------------------------------------------------------
common_sed_escape() {
  printf '%s' "$1" | sed -e 's/[\/&|\\]/\\&/g'
}

# ---------------------------------------------------------------------------
# Version extraction (no Node dependency)
# ---------------------------------------------------------------------------
common_get_version() {
  local project_root="${1:-.}"
  grep '"version"' "$project_root/package.json" 2>/dev/null | head -1 | sed 's/.*: *"\([^"]*\)".*/\1/' || echo "0.0.0"
}
