#!/usr/bin/env bash
# =============================================================================
# deploy/lib/rollback.sh — Checkpoint/rollback stack (DC-1445, DC-1449)
# =============================================================================
# Source this file after common.sh. Defines rollback_* functions.
# Push rollback commands onto a LIFO stack. On ERR, execute in reverse.
# =============================================================================

[[ -n "${_COMPASS_ROLLBACK_LOADED:-}" ]] && return 0
_COMPASS_ROLLBACK_LOADED=1

# ---------------------------------------------------------------------------
# Rollback stack (bash array, LIFO)
# ---------------------------------------------------------------------------
declare -a _ROLLBACK_STACK=()
_ROLLBACK_ENABLED=false
_ROLLBACK_MARKER=""

# ---------------------------------------------------------------------------
# Enable rollback — sets ERR trap
# ---------------------------------------------------------------------------
rollback_enable() {
  local install_dir="${1:-/opt/compass}"
  _ROLLBACK_MARKER="${install_dir}/.compass-installed"
  _ROLLBACK_ENABLED=true

  # Only set trap if not in dry-run mode
  if [[ "${COMPASS_DRY_RUN:-false}" != true ]]; then
    trap '_rollback_execute' ERR
  fi
}

# ---------------------------------------------------------------------------
# Push a rollback command onto the stack
# ---------------------------------------------------------------------------
rollback_push() {
  local cmd="$1"
  local description="${2:-}"

  # Never push rollback for existing installations
  if [[ -f "${_ROLLBACK_MARKER}" ]]; then
    return 0
  fi

  _ROLLBACK_STACK+=("${cmd}")
  if [[ -n "$description" ]]; then
    [[ "$(type -t logging_write 2>/dev/null)" == "function" ]] && \
      logging_write "DEBUG" "rollback_checkpoint description=\"${description}\"" || true
  fi
}

# ---------------------------------------------------------------------------
# Clear the rollback stack (called on success)
# ---------------------------------------------------------------------------
rollback_clear() {
  _ROLLBACK_STACK=()
  _ROLLBACK_ENABLED=false
  trap - ERR
}

# ---------------------------------------------------------------------------
# Execute rollback in LIFO order
# ---------------------------------------------------------------------------
_rollback_execute() {
  local exit_code=$?

  if [[ "$_ROLLBACK_ENABLED" != true ]]; then
    return $exit_code
  fi

  if [[ ${#_ROLLBACK_STACK[@]} -eq 0 ]]; then
    return $exit_code
  fi

  echo ""
  fail "Installation failed (exit code: ${exit_code}). Rolling back..."
  echo ""

  # Execute in reverse (LIFO)
  local i
  for ((i=${#_ROLLBACK_STACK[@]}-1; i>=0; i--)); do
    local cmd="${_ROLLBACK_STACK[$i]}"
    info "Rollback: ${cmd}"
    eval "$cmd" 2>/dev/null || warn "Rollback step failed: ${cmd}"
  done

  _ROLLBACK_STACK=()
  ok "Rollback complete. System restored to pre-install state."

  exit $exit_code
}

# ---------------------------------------------------------------------------
# Mark installation as successful (creates marker file)
# ---------------------------------------------------------------------------
rollback_mark_success() {
  local install_dir="${1:-/opt/compass}"
  local marker="${install_dir}/.compass-installed"
  date -u '+%Y-%m-%dT%H:%M:%SZ' > "$marker" 2>/dev/null || true
  rollback_clear
}
