#!/usr/bin/env bash
# =============================================================================
# deploy/lib/docker-install.sh — Docker Engine auto-installation (DC-1445, DC-1448)
# =============================================================================
# Source this file after common.sh. Defines docker_install_* functions.
# Supports Ubuntu 22.04/24.04, RHEL 8+, Amazon Linux 2023.
# Never auto-installs without user confirmation.
# =============================================================================

[[ -n "${_COMPASS_DOCKER_INSTALL_LOADED:-}" ]] && return 0
_COMPASS_DOCKER_INSTALL_LOADED=1

# ---------------------------------------------------------------------------
# Detect OS family and version from /etc/os-release
# ---------------------------------------------------------------------------
docker_install_detect_os() {
  if [[ ! -f /etc/os-release ]]; then
    echo "unknown"
    return 1
  fi

  local id version_id
  id=$(. /etc/os-release && echo "${ID:-unknown}")
  version_id=$(. /etc/os-release && echo "${VERSION_ID:-0}")

  case "$id" in
    ubuntu)
      echo "ubuntu:${version_id}"
      ;;
    rhel|centos|rocky|almalinux)
      echo "rhel:${version_id}"
      ;;
    amzn)
      echo "amzn:${version_id}"
      ;;
    fedora)
      echo "fedora:${version_id}"
      ;;
    *)
      echo "${id}:${version_id}"
      ;;
  esac
}

# ---------------------------------------------------------------------------
# Check if Docker is already installed
# ---------------------------------------------------------------------------
docker_install_is_installed() {
  command -v docker &>/dev/null
}

# ---------------------------------------------------------------------------
# Install Docker on Ubuntu (from Docker's official repo)
# ---------------------------------------------------------------------------
_docker_install_ubuntu() {
  info "Installing Docker Engine on Ubuntu..."

  # Remove old packages
  apt-get remove -y docker docker-engine docker.io containerd runc 2>/dev/null || true

  # Prerequisites
  apt-get update -y
  apt-get install -y ca-certificates curl gnupg

  # Add Docker's official GPG key
  install -m 0755 -d /etc/apt/keyrings
  curl -fsSL https://download.docker.com/linux/ubuntu/gpg | gpg --dearmor -o /etc/apt/keyrings/docker.gpg --yes
  chmod a+r /etc/apt/keyrings/docker.gpg

  # Set up repository
  local codename
  codename=$(. /etc/os-release && echo "$VERSION_CODENAME")
  echo \
    "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu \
    ${codename} stable" > /etc/apt/sources.list.d/docker.list

  # Install Docker Engine
  apt-get update -y
  apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin

  # Start and enable
  systemctl start docker
  systemctl enable docker

  ok "Docker Engine installed on Ubuntu"
}

# ---------------------------------------------------------------------------
# Install Docker on RHEL/CentOS/Rocky/Alma 8+
# ---------------------------------------------------------------------------
_docker_install_rhel() {
  info "Installing Docker Engine on RHEL/CentOS..."

  # Remove old packages
  yum remove -y docker docker-client docker-client-latest docker-common \
    docker-latest docker-latest-logrotate docker-logrotate docker-engine 2>/dev/null || true

  # Install prerequisites
  yum install -y yum-utils

  # Add Docker repo
  yum-config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo

  # Install Docker Engine
  yum install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin

  # Start and enable
  systemctl start docker
  systemctl enable docker

  ok "Docker Engine installed on RHEL/CentOS"
}

# ---------------------------------------------------------------------------
# Install Docker on Amazon Linux 2023
# ---------------------------------------------------------------------------
_docker_install_amzn() {
  info "Installing Docker Engine on Amazon Linux..."

  # Amazon Linux 2023 uses dnf
  dnf install -y docker

  # Docker Compose plugin may need manual install on AL2023
  local compose_version="v2.24.5"
  local compose_url="https://github.com/docker/compose/releases/download/${compose_version}/docker-compose-linux-$(uname -m)"

  mkdir -p /usr/local/lib/docker/cli-plugins
  curl -fsSL "$compose_url" -o /usr/local/lib/docker/cli-plugins/docker-compose
  chmod +x /usr/local/lib/docker/cli-plugins/docker-compose

  # Start and enable
  systemctl start docker
  systemctl enable docker

  ok "Docker Engine installed on Amazon Linux"
}

# ---------------------------------------------------------------------------
# Main: install Docker with OS detection and user confirmation
# ---------------------------------------------------------------------------
docker_install_run() {
  local auto_confirm="${1:-false}"

  if docker_install_is_installed; then
    ok "Docker is already installed"
    return 0
  fi

  local os_info
  os_info=$(docker_install_detect_os)
  local os_family="${os_info%%:*}"
  local os_version="${os_info##*:}"

  info "Detected OS: ${os_info}"

  # Check if we support this OS
  case "$os_family" in
    ubuntu|rhel|centos|rocky|almalinux|amzn|fedora) ;;
    *)
      fail "Unsupported OS for automatic Docker installation: ${os_family}"
      info "Please install Docker manually: https://docs.docker.com/engine/install/"
      return 1
      ;;
  esac

  # Confirm with user (unless auto-confirmed via --silent + COMPASS_INSTALL_DOCKER=yes)
  if [[ "$auto_confirm" != true ]]; then
    echo ""
    echo -n "  Docker is not installed. Install Docker Engine now? [y/N]: "
    read -r answer
    if [[ ! "$answer" =~ ^[Yy]$ ]]; then
      info "Docker installation skipped. Install manually before proceeding."
      return 1
    fi
  fi

  # Dispatch to OS-specific installer
  case "$os_family" in
    ubuntu)
      _docker_install_ubuntu
      ;;
    rhel|centos|rocky|almalinux|fedora)
      _docker_install_rhel
      ;;
    amzn)
      _docker_install_amzn
      ;;
  esac

  # Verify installation
  if docker_install_is_installed; then
    local docker_version
    docker_version=$(docker version --format '{{.Server.Version}}' 2>/dev/null || echo "unknown")
    ok "Docker Engine v${docker_version} installed successfully"
    return 0
  else
    fail "Docker installation failed. Check output above."
    return 1
  fi
}
