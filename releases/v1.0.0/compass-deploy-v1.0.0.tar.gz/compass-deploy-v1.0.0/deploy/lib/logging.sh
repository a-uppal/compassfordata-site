#!/usr/bin/env bash
# =============================================================================
# deploy/lib/logging.sh — Structured install log writer (DC-1445, DC-1451)
# =============================================================================
# Source this file after common.sh. Defines logging_* functions.
# Writes to $INSTALL_DIR/logs/install.log in structured format.
# =============================================================================

[[ -n "${_COMPASS_LOGGING_LOADED:-}" ]] && return 0
_COMPASS_LOGGING_LOADED=1

_LOGGING_FILE=""
_LOGGING_ENABLED=false

# ---------------------------------------------------------------------------
# Initialize logging — call once at start of install
# ---------------------------------------------------------------------------
logging_init() {
  local install_dir="${1:-/opt/compass}"
  local log_dir="${install_dir}/logs"

  mkdir -p "$log_dir" 2>/dev/null || true
  _LOGGING_FILE="${log_dir}/install.log"
  _LOGGING_ENABLED=true

  logging_write "INFO" "event=install_start install_dir=\"${install_dir}\""
}

# ---------------------------------------------------------------------------
# Write a structured log line
# Format: [ISO8601] [LEVEL] key=value ...
# ---------------------------------------------------------------------------
logging_write() {
  if [[ "$_LOGGING_ENABLED" != true ]] || [[ -z "$_LOGGING_FILE" ]]; then
    return 0
  fi

  local level="${1:-INFO}"
  local message="$2"
  local timestamp
  timestamp=$(date -u '+%Y-%m-%dT%H:%M:%SZ' 2>/dev/null || date '+%Y-%m-%dT%H:%M:%S')

  echo "[${timestamp}] [${level}] ${message}" >> "$_LOGGING_FILE" 2>/dev/null || true
}

# ---------------------------------------------------------------------------
# Log the completion of the install
# ---------------------------------------------------------------------------
logging_finish() {
  local exit_code="${1:-0}"
  if [[ "$exit_code" -eq 0 ]]; then
    logging_write "INFO" "event=install_complete status=success"
  else
    logging_write "ERROR" "event=install_complete status=failed exit_code=${exit_code}"
  fi
}

# ---------------------------------------------------------------------------
# Get log file path
# ---------------------------------------------------------------------------
logging_get_file() {
  echo "$_LOGGING_FILE"
}
