#!/usr/bin/env bash
# =============================================================================
# FAIR Compass - Enterprise Setup Wizard
# =============================================================================
# Root-level TUI wizard for customer deployment. This is the primary entry
# point after extracting the deployment tarball.
#
# Usage:
#   sudo ./setup.sh              # Interactive TUI menu
#   sudo ./setup.sh --install    # Non-interactive install
#   sudo ./setup.sh --uninstall  # Non-interactive uninstall
#   sudo ./setup.sh --health     # Health check only
#   ./setup.sh --version         # Print version and exit
#
# TUI Backends (auto-detected):
#   whiptail > dialog > plain bash (fallback)
# =============================================================================

set -euo pipefail

# ---------------------------------------------------------------------------
# Globals
# ---------------------------------------------------------------------------
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VERSION=$(grep '"version"' "$SCRIPT_DIR/package.json" 2>/dev/null | head -1 | sed 's/.*: *"\([^"]*\)".*/\1/' || echo "0.0.0")
PRODUCT_NAME="DATA Compass"
INSTALL_DIR="${COMPASS_INSTALL_DIR:-/opt/compass}"
COMPASS_PORT="${COMPASS_PORT:-3001}"
COMPASS_SILENT="${COMPASS_SILENT:-false}"
TUI_BACKEND=""
COMPOSE_FILES="-f docker-compose.yml -f docker-compose.prod.yml"
CONFIG_FILE="${INSTALL_DIR}/compass-config.yaml"

# ---------------------------------------------------------------------------
# Source deploy/lib/ if available (DC-1453)
# ---------------------------------------------------------------------------
_SETUP_LIB_DIR="${SCRIPT_DIR}/deploy/lib"
if [[ -d "$_SETUP_LIB_DIR" && -f "$_SETUP_LIB_DIR/common.sh" ]]; then
  . "$_SETUP_LIB_DIR/common.sh"
  . "$_SETUP_LIB_DIR/preflight.sh"
  . "$_SETUP_LIB_DIR/docker-install.sh"
  _SETUP_HAS_LIB=true
else
  _SETUP_HAS_LIB=false

  # Fallback: inline colors & helpers
  if [[ -n "${NO_COLOR:-}" ]] || [ ! -t 1 ]; then
    RED=''; GREEN=''; YELLOW=''; BLUE=''; CYAN=''; BOLD=''; DIM=''; NC=''
  else
    RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
    BLUE='\033[0;34m'; CYAN='\033[0;36m'; BOLD='\033[1m'; DIM='\033[2m'; NC='\033[0m'
  fi

  ok()   { echo -e "  ${GREEN}[OK]${NC} $1"; }
  warn() { echo -e "  ${YELLOW}[WARN]${NC} $1"; }
  fail() { echo -e "  ${RED}[FAIL]${NC} $1"; }
  info() { echo -e "  ${CYAN}[INFO]${NC} $1"; }

  # Inline spinner (fallback)
  _spinner_pid=""
  start_spinner() {
    local msg="${1:-Working...}"
    if [ -t 1 ]; then
      (
        local chars='|/-\'
        local i=0
        while true; do
          printf "\r  %s %s " "${chars:i%4:1}" "$msg"
          i=$((i + 1))
          sleep 0.15
        done
      ) &
      _spinner_pid=$!
      disown "$_spinner_pid" 2>/dev/null || true
    fi
  }
  stop_spinner() {
    if [ -n "$_spinner_pid" ]; then
      kill "$_spinner_pid" 2>/dev/null || true
      wait "$_spinner_pid" 2>/dev/null || true
      _spinner_pid=""
      printf "\r\033[K"
    fi
  }

  step_header() {
    local title="$1"
    local width=${#title}
    local pad=$((width + 4))
    echo ""
    if locale charmap 2>/dev/null | grep -qi utf; then
      printf "  ${BOLD}${BLUE}"
      printf '\u250C'; printf '\u2500%.0s' $(seq 1 $pad); printf '\u2510\n'
      printf '  \u2502  %s  \u2502\n' "$title"
      printf '  \u2514'; printf '\u2500%.0s' $(seq 1 $pad); printf '\u2518'
      printf "${NC}\n"
    else
      printf "  ${BOLD}${BLUE}"
      printf '+'; printf -- '-%.0s' $(seq 1 $pad); printf '+\n'
      printf '  |  %s  |\n' "$title"
      printf '  +'; printf -- '-%.0s' $(seq 1 $pad); printf '+'
      printf "${NC}\n"
    fi
    echo ""
  }
fi

trap 'stop_spinner 2>/dev/null || true' EXIT

# ---------------------------------------------------------------------------
# ASCII art banner
# ---------------------------------------------------------------------------
show_banner() {
  if locale charmap 2>/dev/null | grep -qi utf; then
    cat <<'BANNER_UTF8'

    ╔══════════════════════════════════════════════╗
    ║                                              ║
    ║       ██████╗  █████╗ ████████╗ █████╗       ║
    ║       ██╔══██╗██╔══██╗╚══██╔══╝██╔══██╗      ║
    ║       ██║  ██║███████║   ██║   ███████║      ║
    ║       ██║  ██║██╔══██║   ██║   ██╔══██║      ║
    ║       ██████╔╝██║  ██║   ██║   ██║  ██║      ║
    ║       ╚═════╝ ╚═╝  ╚═╝   ╚═╝   ╚═╝  ╚═╝      ║
    ║          C O M P A S S                       ║
    ║                                              ║
    ╚══════════════════════════════════════════════╝

BANNER_UTF8
  else
    cat <<'BANNER_ASCII'

    +----------------------------------------------+
    |                                              |
    |       ____    _  _____  _                    |
    |      |  _ \  / \|_   _|/ \                   |
    |      | | | |/ _ \ | | / _ \                  |
    |      | |_| / ___ \| |/ ___ \                 |
    |      |____/_/   \_\_/_/   \_\                |
    |          C O M P A S S                       |
    |                                              |
    +----------------------------------------------+

BANNER_ASCII
  fi

  echo -e "    ${BOLD}${PRODUCT_NAME}${NC} v${VERSION}"
  echo -e "    ${DIM}Enterprise Setup Wizard${NC}"
  echo ""
}

# =============================================================================
# TUI BACKEND DETECTION
# =============================================================================
detect_tui() {
  if command -v whiptail &>/dev/null; then
    TUI_BACKEND="whiptail"
  elif command -v dialog &>/dev/null; then
    TUI_BACKEND="dialog"
  else
    TUI_BACKEND="bash"
  fi
}

# =============================================================================
# TUI DISPATCHERS
# =============================================================================
# Each interaction dispatches to the detected backend.

# show_menu TITLE ITEM1 TAG1 ITEM2 TAG2 ...
# Returns the selected tag on stdout
show_menu() {
  local title="$1"; shift
  case "$TUI_BACKEND" in
    whiptail) show_menu_whiptail "$title" "$@" ;;
    dialog)   show_menu_dialog   "$title" "$@" ;;
    *)        show_menu_bash     "$title" "$@" ;;
  esac
}

show_menu_whiptail() {
  local title="$1"; shift
  local items=()
  while [[ $# -ge 2 ]]; do
    items+=("$1" "$2")
    shift 2
  done
  whiptail --title "$PRODUCT_NAME v$VERSION" --menu "$title" 20 60 10 "${items[@]}" 3>&1 1>&2 2>&3 || echo "QUIT"
}

show_menu_dialog() {
  local title="$1"; shift
  local items=()
  while [[ $# -ge 2 ]]; do
    items+=("$1" "$2")
    shift 2
  done
  dialog --title "$PRODUCT_NAME v$VERSION" --menu "$title" 20 60 10 "${items[@]}" 2>&1 >/dev/tty || echo "QUIT"
}

show_menu_bash() {
  local title="$1"; shift
  local tags=()
  local descs=()
  local i=1

  while [[ $# -ge 2 ]]; do
    tags+=("$1")
    descs+=("$2")
    shift 2
  done

  echo ""
  echo -e "  ${BOLD}${title}${NC}"
  echo ""
  for idx in "${!tags[@]}"; do
    printf "    ${CYAN}%d)${NC}  %-12s  %s\n" "$((idx + 1))" "${tags[$idx]}" "${descs[$idx]}"
  done
  printf "    ${CYAN}q)${NC}  %-12s  %s\n" "Quit" "Exit setup wizard"
  echo ""

  while true; do
    echo -n "  Select [1-${#tags[@]}/q]: "
    read -r choice
    if [[ "$choice" == "q" || "$choice" == "Q" ]]; then
      echo "QUIT"
      return
    fi
    if [[ "$choice" =~ ^[0-9]+$ ]] && [ "$choice" -ge 1 ] && [ "$choice" -le "${#tags[@]}" ]; then
      echo "${tags[$((choice - 1))]}"
      return
    fi
    echo -e "  ${RED}Invalid choice.${NC}"
  done
}

# show_yesno PROMPT -> returns 0 for yes, 1 for no
show_yesno() {
  local prompt="$1"
  case "$TUI_BACKEND" in
    whiptail) show_yesno_whiptail "$prompt" ;;
    dialog)   show_yesno_dialog   "$prompt" ;;
    *)        show_yesno_bash     "$prompt" ;;
  esac
}

show_yesno_whiptail() {
  whiptail --title "$PRODUCT_NAME" --yesno "$1" 10 60
}

show_yesno_dialog() {
  dialog --title "$PRODUCT_NAME" --yesno "$1" 10 60 2>&1 >/dev/tty
}

show_yesno_bash() {
  echo ""
  echo -n "  $1 [y/N]: "
  read -r answer
  [[ "$answer" =~ ^[Yy]$ ]]
}

# show_input PROMPT DEFAULT -> returns value on stdout
show_input() {
  local prompt="$1"
  local default="${2:-}"
  case "$TUI_BACKEND" in
    whiptail) show_input_whiptail "$prompt" "$default" ;;
    dialog)   show_input_dialog   "$prompt" "$default" ;;
    *)        show_input_bash     "$prompt" "$default" ;;
  esac
}

show_input_whiptail() {
  whiptail --title "$PRODUCT_NAME" --inputbox "$1" 10 60 "$2" 3>&1 1>&2 2>&3 || echo "$2"
}

show_input_dialog() {
  dialog --title "$PRODUCT_NAME" --inputbox "$1" 10 60 "$2" 2>&1 >/dev/tty || echo "$2"
}

show_input_bash() {
  echo ""
  if [ -n "$2" ]; then
    echo -n "  $1 [$2]: "
  else
    echo -n "  $1: "
  fi
  read -r value
  echo "${value:-$2}"
}

# show_password PROMPT -> returns value on stdout (hidden input)
show_password() {
  local prompt="$1"
  case "$TUI_BACKEND" in
    whiptail) show_password_whiptail "$prompt" ;;
    dialog)   show_password_dialog   "$prompt" ;;
    *)        show_password_bash     "$prompt" ;;
  esac
}

show_password_whiptail() {
  whiptail --title "$PRODUCT_NAME" --passwordbox "$1" 10 60 3>&1 1>&2 2>&3 || echo ""
}

show_password_dialog() {
  dialog --title "$PRODUCT_NAME" --insecure --passwordbox "$1" 10 60 2>&1 >/dev/tty || echo ""
}

show_password_bash() {
  echo ""
  echo -n "  $1: "
  read -rs value
  echo "" >&2
  echo "$value"
}

# =============================================================================
# ACTION: INSTALL (DC-1453 — Docker auto-install + preflight wiring)
# =============================================================================
do_install() {
  step_header "Install ${PRODUCT_NAME}"

  # Pre-install Docker check: if Docker missing and lib available, offer auto-install
  if [[ "$_SETUP_HAS_LIB" == true ]] && ! preflight_check_docker 2>/dev/null; then
    echo ""
    if [[ "$COMPASS_SILENT" == true ]]; then
      if [[ "${COMPASS_INSTALL_DOCKER:-}" == "yes" ]]; then
        docker_install_run true || { fail "Docker auto-install failed."; return 1; }
      else
        fail "Docker not found. Set COMPASS_INSTALL_DOCKER=yes for auto-install."
        return 1
      fi
    else
      if show_yesno "Docker is not installed. Install Docker Engine automatically?"; then
        docker_install_run false || { fail "Docker auto-install failed."; return 1; }
      else
        fail "Docker is required. Install it manually: https://docs.docker.com/engine/install/"
        return 1
      fi
    fi
  fi

  local extra_args=()

  if [[ -d "$SCRIPT_DIR/deploy" && -f "$SCRIPT_DIR/deploy/install.sh" ]]; then
    info "Delegating to deploy/install.sh..."
    echo ""

    # Pass through any extra flags
    if [[ -d "$SCRIPT_DIR/compass-images.tar.gz" ]] || [[ -f "$SCRIPT_DIR/compass-images.tar.gz" ]]; then
      extra_args+=("--offline")
    fi

    extra_args+=("--install-dir" "$INSTALL_DIR")

    # Pass --silent through if active
    if [[ "$COMPASS_SILENT" == true ]]; then
      extra_args+=("--silent")
    fi

    bash "$SCRIPT_DIR/deploy/install.sh" "${extra_args[@]}" "$@"
  else
    fail "deploy/install.sh not found in $SCRIPT_DIR"
    fail "Ensure you extracted the full deployment bundle."
    return 1
  fi
}

# =============================================================================
# ACTION: CONFIGURE
# =============================================================================
do_configure() {
  step_header "Configure ${PRODUCT_NAME}"

  local config_template="${SCRIPT_DIR}/compass-config.yaml.template"
  local config_dest="$CONFIG_FILE"

  if [ ! -f "$config_dest" ] && [ -f "$config_template" ]; then
    info "No config file found. Creating from template..."
    cp "$config_template" "$config_dest"
    chmod 600 "$config_dest"
  fi

  local choice
  choice=$(show_menu "Configuration Mode" \
    "Guided"  "Set the 6 key settings interactively" \
    "Editor"  "Open config in \$EDITOR" \
    "Back"    "Return to main menu")

  case "$choice" in
    Guided)
      do_configure_guided "$config_dest"
      ;;
    Editor)
      if [ -f "$config_dest" ]; then
        ${EDITOR:-vi} "$config_dest"
        ok "Config saved: $config_dest"
      else
        fail "Config file not found: $config_dest"
      fi
      ;;
    Back|QUIT)
      return 0
      ;;
  esac
}

do_configure_guided() {
  local dest="$1"

  if [ ! -f "$dest" ]; then
    fail "Config file not found: $dest"
    return 1
  fi

  info "Guided configuration - press Enter to keep current value"
  echo ""

  # 1. Database password
  local db_pass
  db_pass=$(show_password "Database password (leave empty to auto-generate)")
  if [ -z "$db_pass" ]; then
    db_pass=$(openssl rand -base64 32 | tr -d '/+=' | head -c 32)
    info "Auto-generated database password"
  fi

  # 2. JWT secret
  local jwt_secret
  jwt_secret=$(openssl rand -base64 48 | tr -d '/+=' | head -c 48)
  info "Auto-generated JWT secret"

  # 2b. MFA encryption key
  local mfa_key
  mfa_key=$(openssl rand -base64 32 | tr -d '/+=' | head -c 32)
  info "Auto-generated MFA encryption key"

  # 3. AI API key
  local ai_key
  ai_key=$(show_password "Anthropic API key (sk-ant-...)")

  # 4. HTTP proxy
  local proxy_url
  proxy_url=$(show_input "HTTP proxy URL (empty for none)" "")

  # 5. Branding / product name
  local brand_name
  brand_name=$(show_input "Product display name" "$PRODUCT_NAME")

  # 6. Customer name
  local customer_name
  customer_name=$(show_input "Customer / organization name" "")

  # Sanitize user-provided values for safe sed substitution
  # Auto-generated secrets (db_pass, jwt_secret, mfa_key) are base64 alphanumeric — safe as-is
  local safe_ai_key safe_proxy safe_brand safe_customer
  if [[ "$(type -t common_sed_escape 2>/dev/null)" == "function" ]]; then
    safe_ai_key=$(common_sed_escape "${ai_key:-}")
    safe_proxy=$(common_sed_escape "${proxy_url}")
    safe_brand=$(common_sed_escape "${brand_name}")
    safe_customer=$(common_sed_escape "${customer_name}")
  else
    # Fallback: inline escape of sed special chars (\ / & |)
    safe_ai_key=$(printf '%s' "${ai_key:-}" | sed -e 's/[\/&|\\]/\\&/g')
    safe_proxy=$(printf '%s' "${proxy_url}" | sed -e 's/[\/&|\\]/\\&/g')
    safe_brand=$(printf '%s' "${brand_name}" | sed -e 's/[\/&|\\]/\\&/g')
    safe_customer=$(printf '%s' "${customer_name}" | sed -e 's/[\/&|\\]/\\&/g')
  fi

  # Apply to config via comment-anchor sed pattern
  sed -i.bak \
    -e "/# INSTALLER_REPLACE:db_password/c\\  password: \"${db_pass}\"" \
    -e "/# INSTALLER_REPLACE:jwt_secret/c\\  jwt_secret: \"${jwt_secret}\"" \
    -e "/# INSTALLER_REPLACE:mfa_encryption_key/c\\  mfa_encryption_key: \"${mfa_key}\"" \
    -e "/# INSTALLER_REPLACE:ai_api_key/c\\  api_key: \"${safe_ai_key}\"" \
    -e "s|http_proxy: \"\"|http_proxy: \"${safe_proxy}\"|" \
    -e "s|https_proxy: \"\"|https_proxy: \"${safe_proxy}\"|" \
    -e "s|product_name: .*|product_name: \"${safe_brand}\"|" \
    -e "s|customer_name: .*|customer_name: \"${safe_customer}\"|" \
    "$dest"

  rm -f "${dest}.bak"
  chmod 600 "$dest"
  ok "Configuration updated: $dest"
}

# =============================================================================
# ACTION: HEALTH CHECK
# =============================================================================
do_health() {
  step_header "Health Check"

  local errors=0

  # Check Docker
  echo -e "  ${BOLD}Docker:${NC}"
  if command -v docker &>/dev/null; then
    ok "Docker installed: $(docker --version 2>/dev/null | head -1)"
  else
    fail "Docker not found"
    errors=$((errors + 1))
  fi

  if docker compose version &>/dev/null; then
    ok "Docker Compose: $(docker compose version --short 2>/dev/null)"
  else
    fail "Docker Compose v2 not found"
    errors=$((errors + 1))
  fi

  # Check containers
  echo ""
  echo -e "  ${BOLD}Containers:${NC}"
  if docker compose ps --format '{{.Name}} {{.Status}}' 2>/dev/null | grep -q .; then
    docker compose ps --format '{{.Name}} {{.Status}}' 2>/dev/null | while read -r name status; do
      if echo "$status" | grep -qi "up\|running"; then
        ok "$name: $status"
      else
        fail "$name: $status"
      fi
    done
  else
    warn "No containers found (is the application running?)"
  fi

  # Check health endpoints
  echo ""
  echo -e "  ${BOLD}Health Endpoints:${NC}"

  local base_url="http://localhost:${COMPASS_PORT}"
  for endpoint in /health /health/ready /health/live; do
    local url="${base_url}${endpoint}"
    local http_code
    http_code=$(curl -sf -o /dev/null -w "%{http_code}" "$url" 2>/dev/null || echo "000")
    if [ "$http_code" = "200" ]; then
      ok "${endpoint} -> HTTP ${http_code}"
    else
      fail "${endpoint} -> HTTP ${http_code}"
      errors=$((errors + 1))
    fi
  done

  echo ""
  if [ "$errors" -eq 0 ]; then
    ok "All health checks passed"
  else
    fail "${errors} check(s) failed"
  fi

  return $errors
}

# =============================================================================
# ACTION: VIEW LOGS
# =============================================================================
do_logs() {
  step_header "View Logs"

  local choice
  choice=$(show_menu "Select log source" \
    "All"      "All container logs (last 100 lines)" \
    "App"      "Application container logs" \
    "Database" "PostgreSQL container logs" \
    "Follow"   "Follow all logs in real-time" \
    "Back"     "Return to main menu")

  local cd_dir="$INSTALL_DIR"
  [ -f "$SCRIPT_DIR/docker-compose.yml" ] && cd_dir="$SCRIPT_DIR"

  case "$choice" in
    All)
      (cd "$cd_dir" && docker compose logs --tail 100 2>/dev/null) || fail "Could not retrieve logs"
      ;;
    App)
      (cd "$cd_dir" && docker compose logs --tail 100 app 2>/dev/null) || fail "Could not retrieve app logs"
      ;;
    Database)
      (cd "$cd_dir" && docker compose logs --tail 100 postgres 2>/dev/null) || fail "Could not retrieve database logs"
      ;;
    Follow)
      info "Press Ctrl+C to stop following logs"
      (cd "$cd_dir" && docker compose logs -f 2>/dev/null) || fail "Could not follow logs"
      ;;
    Back|QUIT)
      return 0
      ;;
  esac
}

# =============================================================================
# ACTION: BACKUP / RESTORE
# =============================================================================
do_backup() {
  step_header "Backup / Restore"

  local backup_script="$SCRIPT_DIR/deploy/backup.sh"
  if [ ! -f "$backup_script" ]; then
    backup_script="$INSTALL_DIR/deploy/backup.sh"
  fi

  if [ ! -f "$backup_script" ]; then
    fail "backup.sh not found"
    return 1
  fi

  local choice
  choice=$(show_menu "Backup / Restore" \
    "Backup"  "Create a new database backup" \
    "Restore" "Restore from an existing backup" \
    "List"    "List available backups" \
    "Back"    "Return to main menu")

  case "$choice" in
    Backup)
      bash "$backup_script"
      ;;
    Restore)
      bash "$backup_script" --list
      local restore_file
      restore_file=$(show_input "Path to backup file" "")
      if [ -n "$restore_file" ] && [ -f "$restore_file" ]; then
        bash "$backup_script" --restore "$restore_file"
      else
        fail "Invalid backup file path"
      fi
      ;;
    List)
      bash "$backup_script" --list
      ;;
    Back|QUIT)
      return 0
      ;;
  esac
}

# =============================================================================
# ACTION: UNINSTALL
# =============================================================================
do_uninstall() {
  step_header "Uninstall ${PRODUCT_NAME}"

  local choice
  choice=$(show_menu "Uninstall Mode" \
    "Stop"  "Stop containers (keep data and images)" \
    "Purge" "Remove containers, images, AND all data" \
    "Back"  "Return to main menu")

  case "$choice" in
    Stop)
      if show_yesno "Stop all ${PRODUCT_NAME} containers?"; then
        start_spinner "Stopping containers..."
        local cd_dir="$INSTALL_DIR"
        [ -f "$SCRIPT_DIR/docker-compose.yml" ] && cd_dir="$SCRIPT_DIR"
        (cd "$cd_dir" && docker compose down 2>/dev/null) || true
        stop_spinner
        ok "Containers stopped. Data preserved in ${INSTALL_DIR}/data/"
      fi
      ;;
    Purge)
      warn "This will PERMANENTLY DELETE all data, containers, and images!"
      echo ""
      echo -n "  Type 'PURGE' to confirm: "
      read -r confirm
      if [ "$confirm" = "PURGE" ]; then
        start_spinner "Removing all data..."
        local cd_dir="$INSTALL_DIR"
        [ -f "$SCRIPT_DIR/docker-compose.yml" ] && cd_dir="$SCRIPT_DIR"
        (cd "$cd_dir" && docker compose down -v --rmi all 2>/dev/null) || true
        stop_spinner

        if show_yesno "Also remove ${INSTALL_DIR} directory?"; then
          rm -rf "$INSTALL_DIR"
          ok "Installation directory removed"
        fi

        ok "Uninstall complete"
      else
        info "Purge cancelled (expected 'PURGE')"
      fi
      ;;
    Back|QUIT)
      return 0
      ;;
  esac
}

# =============================================================================
# ACTION: HELP
# =============================================================================
do_help() {
  step_header "Quick Reference"

  cat <<HELP_TEXT
  ${BOLD}${PRODUCT_NAME} v${VERSION} - Quick Reference${NC}

  ${BOLD}Files:${NC}
    Config:     ${CONFIG_FILE}
    Logs:       docker compose logs -f app
    Backups:    ${INSTALL_DIR}/data/backups/

  ${BOLD}Common Commands:${NC}
    Start:      docker compose ${COMPOSE_FILES} up -d
    Stop:       docker compose down
    Restart:    docker compose ${COMPOSE_FILES} restart app
    Status:     docker compose ps
    Logs:       docker compose logs -f app

  ${BOLD}Health Endpoints:${NC}
    Liveness:   curl http://localhost:${COMPASS_PORT}/health/live
    Readiness:  curl http://localhost:${COMPASS_PORT}/health/ready
    Full:       curl http://localhost:${COMPASS_PORT}/health

  ${BOLD}Backup:${NC}
    Create:     ./deploy/backup.sh
    Restore:    ./deploy/backup.sh --restore <file>
    List:       ./deploy/backup.sh --list

  ${BOLD}Admin:${NC}
    Create user:  ./deploy/create-admin.sh --org "Org" --email admin@example.com

  ${BOLD}Documentation:${NC}
    Install guide:  deploy/INSTALLATION_GUIDE.md
    Network reqs:   deploy/NETWORK_REQUIREMENTS.md
    Runbook:        deploy/CONSULTANT_RUNBOOK.md

HELP_TEXT
}

# =============================================================================
# MAIN MENU LOOP
# =============================================================================
main_menu() {
  while true; do
    local choice
    choice=$(show_menu "Main Menu - Choose an action:" \
      "Install"   "Install ${PRODUCT_NAME}" \
      "Configure" "Edit configuration settings" \
      "Health"    "Verify system health" \
      "Logs"      "View application logs" \
      "Backup"    "Backup or restore database" \
      "Uninstall" "Stop or remove installation" \
      "Help"      "Quick reference card")

    case "$choice" in
      Install)   do_install ;;
      Configure) do_configure ;;
      Health)    do_health || true ;;
      Logs)      do_logs ;;
      Backup)    do_backup ;;
      Uninstall) do_uninstall ;;
      Help)      do_help ;;
      QUIT)
        echo ""
        info "Goodbye!"
        exit 0
        ;;
    esac

    # Pause before returning to menu (bash fallback only)
    if [ "$TUI_BACKEND" = "bash" ]; then
      echo ""
      echo -n "  Press Enter to return to menu..."
      read -r
    fi
  done
}

# =============================================================================
# CLI FLAGS (non-interactive mode)
# =============================================================================
parse_cli() {
  # Collect pass-through args first, then dispatch
  local action=""
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --install)
        action="install"
        shift
        ;;
      --uninstall)
        action="uninstall"
        shift
        ;;
      --health)
        action="health"
        shift
        ;;
      --silent)
        COMPASS_SILENT=true
        export COMPASS_SILENT
        shift
        ;;
      --dry-run)
        export COMPASS_DRY_RUN=true
        shift
        ;;
      --version)
        echo "${PRODUCT_NAME} v${VERSION}"
        exit 0
        ;;
      --install-dir)
        INSTALL_DIR="$2"
        CONFIG_FILE="${INSTALL_DIR}/compass-config.yaml"
        shift 2
        ;;
      -h|--help)
        echo "Usage: $0 [OPTIONS]"
        echo ""
        echo "Options:"
        echo "  --install       Run installation non-interactively"
        echo "  --uninstall     Run uninstall"
        echo "  --health        Run health checks only"
        echo "  --silent        Unattended mode (reads COMPASS_* env vars)"
        echo "  --dry-run       Preview plan without making changes"
        echo "  --version       Print version and exit"
        echo "  --install-dir   Set installation directory (default: /opt/compass)"
        echo "  -h, --help      Show this help"
        echo ""
        echo "Without options, launches the interactive TUI menu."
        exit 0
        ;;
      *)
        echo -e "${RED}Unknown option: $1${NC}" >&2
        echo "Run '$0 --help' for usage." >&2
        exit 1
        ;;
    esac
  done

  # Dispatch action if one was set
  case "${action}" in
    install)
      detect_tui
      show_banner
      do_install
      exit $?
      ;;
    uninstall)
      detect_tui
      show_banner
      do_uninstall
      exit $?
      ;;
    health)
      detect_tui
      do_health
      exit $?
      ;;
  esac
}

# =============================================================================
# ENTRY POINT
# =============================================================================
main() {
  # Handle CLI flags first (may exit)
  if [[ $# -gt 0 ]]; then
    parse_cli "$@"
    # If parse_cli returns (e.g., only --install-dir was set), fall through to TUI
  fi

  # Interactive mode
  detect_tui
  show_banner
  main_menu
}

main "$@"
